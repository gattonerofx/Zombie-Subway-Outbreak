// ============================================================================
// NEON RACER — Pseudo-3D Racing Engine
// Self-contained simulation: track, physics, AI, collisions. No rendering here.
// Classic "OutRun-style" segment projection. See render.ts for drawing.
// ============================================================================

// ----- World / projection constants -----
export const SEGMENT_LENGTH = 200;       // world-units per road segment
export const RUMBLE_LENGTH = 3;          // segments per rumble color band
export const ROAD_WIDTH = 2000;          // half-width of drivable road (world units)
export const LANES = 3;
export const CAMERA_HEIGHT = 1000;       // chase-cam height above road
export const FOV = 100;
export const CAMERA_DEPTH = 1 / Math.tan(((FOV / 2) * Math.PI) / 180); // ~0.84
export const DRAW_DISTANCE = 260;        // segments rendered ahead
export const FOG_DENSITY = 5;
export const PLAYER_Z = CAMERA_HEIGHT * CAMERA_DEPTH; // player sprite anchor ahead of camera

// ----- Physics constants -----
export const MAX_SPEED = SEGMENT_LENGTH * 60;          // top speed (world-u/s)
export const ACCEL = MAX_SPEED / 3.2;                   // faster acceleration for responsiveness
export const BRAKING = -MAX_SPEED / 1.2;                // stronger brakes
export const DECEL = -MAX_SPEED / 8;                    // gentler engine braking (coast longer)
export const OFF_ROAD_DECEL = -MAX_SPEED / 1.3;
export const OFF_ROAD_LIMIT = MAX_SPEED / 3.5;
export const CENTRIFUGAL = 0.30;          // pull on curves
export const NITRO_BOOST = 1.45;
export const NITRO_DRAIN = 24;            // per second
export const NITRO_REGEN = 8;             // per second
export const BUMP_BOOST = 1.0;            // nitro gained on a clean bump

// ----- Steering tuning -----
export const STEER_LERP = 11;             // steering smoothing rate (higher = more responsive)
export const STEER_RETURN_LERP = 16;      // return-to-center rate when no input (snappier)
export const STEER_MIN = 0.45;            // minimum steer authority at standstill (so low-speed turns work)
export const STEER_MAX = 1.9;             // max steer authority
export const STEER_SPEED_FALLOFF = 0.55;  // how much speed reduces steer (lower = less understeer at speed)

// ----- Types -----
export type ViewMode = "chase" | "hood" | "cockpit";

export interface GameInput {
  left: boolean;
  right: boolean;
  accel: boolean;
  brake: boolean;
  nitro: boolean;
  // analog values (0..1) — set by gamepad, defaults to 1 for keyboard
  steerAnalog?: number;  // -1 (full left) .. +1 (full right); 0 = centered
  accelAnalog?: number;  // 0..1 throttle
  brakeAnalog?: number;  // 0..1 brake
}

interface Point3 {
  world: { x: number; y: number; z: number };
  camera: { x: number; y: number; z: number };
  screen: { x: number; y: number; w: number; scale: number };
}

export interface Car {
  offset: number;       // lateral -1..1 (fraction of ROAD_WIDTH)
  z: number;            // distance along track (world units)
  speed: number;        // world-u/s
  color: string;        // body color
  accent: string;       // accent/taillight color
  name: string;
  spin: number;         // spinout timer (s); >0 means out of control
  spinDir: number;      // -1 / 1 drift direction when spinning
  wobble: number;       // visual wobble phase
  laps: number;
  finished: boolean;
}

interface Segment {
  index: number;
  p1: Point3;
  p2: Point3;
  curve: number;
  color: "light" | "dark";
  cars: Car[];
  clip: number;
  looped: boolean;
  fog: number;
  scenery: SceneryItem[];
  pad?: TurboPad;   // optional turbo boost pad on this segment
  roadX: number;    // accumulated curve lateral offset at p1 (set during road render pass)
}

export interface TurboPad {
  offset: number;   // lateral center -1..1
  width: number;    // lateral half-width (fraction of ROAD_WIDTH)
  color: string;    // neon glow color
  phase: number;    // animation phase offset
}

export type SceneryKind = "billboard" | "palm" | "lamp" | "arch";

export interface SceneryItem {
  kind: SceneryKind;
  side: -1 | 1;       // left / right of road
  offset: number;     // multiplier of road-half-width (1.4 = just off road)
  color: string;      // neon accent
  variant: number;    // for billboard text / palm shape
}

export interface ScenerySprite extends SceneryItem {
  sx: number;
  sy: number;
  scale: number;
  z: number;
}

export interface CarSprite {
  sx: number;       // screen center x
  sy: number;       // screen baseline y (bottom of car)
  destW: number;    // car sprite width in px
  car: Car;
  isPlayer?: boolean;
  z: number;        // for depth sort
}

export interface RenderState {
  baseSegmentIndex: number;
  basePercent: number;
  playerY: number;
  playerSegmentIndex: number;
  playerPercent: number;
  speedPercent: number;
  rankedCars: { car: Car; isPlayer: boolean }[];
  position: number;
}

export class GameEngine {
  width: number;
  height: number;
  segments: Segment[] = [];
  trackLength = 0;
  cars: Car[] = [];

  // player state
  playerX = 0;          // -1..1 lateral
  position = 0;         // z along track
  speed = 0;
  steering = 0;         // -1..1 smoothed steering (for wheel)
  nitro = 100;          // 0..100
  lap = 0;
  totalLaps = 3;
  crashed = 0;          // crash flash timer
  shake = 0;            // screen-shake intensity (decays)
  onPad = false;        // currently over a turbo pad (for renderer flash)

  // combo / score system
  combo = 0;            // consecutive skill actions (bumps, pads, etc.)
  comboTimer = 0;       // seconds remaining before combo resets
  score = 0;            // accumulated score
  padCooldown = 0;      // prevents pad re-trigger every frame

  // drift system
  drifting = false;     // currently in a sustained drift
  driftTimer = 0;       // how long the current drift has lasted (s)
  driftScore = 0;       // points accumulated in the current drift
  driftCooldown = 0;    // prevents immediate re-drift after ending

  // timing
  startTime = 0;
  currentTime = 0;
  bestTime = 0;
  bestLapTime = 0;      // best single-lap time
  lastLapTime = 0;      // time of most recent lap completion
  lapSplits: number[] = [];   // per-lap completion times
  raceState: "countdown" | "racing" | "finished" = "countdown";
  countdown = 3.2;

  view: ViewMode = "chase";

  // gameplay config
  difficulty: "easy" | "normal" | "hard" = "normal";
  trackId: 1 | 2 | 3 | 4 | 5 | 6 = 1;
  mirror = false; // reverse track direction when true

  // ghost replay state (set by the React layer)
  ghost: { z: number; offset: number } | null = null;
  ghostLapTime = 0; // the ghost's recorded lap time (0 = no ghost)
  ghostEnabled = false; // whether a ghost is loaded for this track
  ghostDelta = 0; // live: player's z minus ghost's z at the same lap-elapsed time (positive = ahead)

  // weather grip multiplier (1 = dry, <1 = wet/reduced grip); set per track
  grip = 1;

  // exposed billboard texts (shared with renderer)
  billboardTexts = ["NEON", "SPEED", "BOOST", "RACE", "TURBO", "DRIFT", "NITRO"];

  // pre-built palette for car colors
  private carPalette = [
    { body: "#ff3b6b", accent: "#ffe14d", name: "Crimson" },
    { body: "#22d3ee", accent: "#ffffff", name: "Cyan" },
    { body: "#a855f7", accent: "#f0abfc", name: "Violet" },
    { body: "#f97316", accent: "#fffbeb", name: "Blaze" },
    { body: "#22c55e", accent: "#fef9c3", name: "Venom" },
    { body: "#eab308", accent: "#1e1e2e", name: "Gold" },
    { body: "#ec4899", accent: "#fef3c7", name: "Flamingo" },
    { body: "#14b8a6", accent: "#fff7ed", name: "Mint" },
    { body: "#f43f5e", accent: "#fff1f2", name: "Rocket" },
    { body: "#8b5cf6", accent: "#fdf4ff", name: "Nova" },
  ];

  constructor(width: number, height: number) {
    this.width = width;
    this.height = height;
    this.reset();
  }

  resize(width: number, height: number) {
    this.width = width;
    this.height = height;
  }

  // ---------------- Track construction ----------------
  private lastY() {
    const s = this.segments[this.segments.length - 1];
    return s ? s.p2.world.y : 0;
  }

  private addSegment(curve: number, y: number) {
    const n = this.segments.length;
    const color: "light" | "dark" =
      Math.floor(n / RUMBLE_LENGTH) % 2 === 0 ? "light" : "dark";
    this.segments.push({
      index: n,
      p1: this.makePoint(n * SEGMENT_LENGTH, this.lastY()),
      p2: this.makePoint((n + 1) * SEGMENT_LENGTH, y),
      curve,
      color,
      cars: [],
      clip: 0,
      looped: false,
      fog: 0,
      scenery: [],
      roadX: 0,
    });
  }

  private makePoint(z: number, y: number): Point3 {
    return {
      world: { x: 0, y, z },
      camera: { x: 0, y: 0, z: 0 },
      screen: { x: 0, y: 0, w: 0, scale: 0 },
    };
  }

  private addRoad(enter: number, hold: number, leave: number, curve: number, hill: number) {
    const startY = this.lastY();
    const endY = startY + hill * SEGMENT_LENGTH;
    const total = enter + hold + leave;
    for (let n = 0; n < enter; n++)
      this.addSegment(this.easeIn(0, curve, n / enter), this.easeInOut(startY, endY, n / total));
    for (let n = 0; n < hold; n++)
      this.addSegment(curve, this.easeInOut(startY, endY, (enter + n) / total));
    for (let n = 0; n < leave; n++)
      this.addSegment(this.easeInOut(curve, 0, n / leave), this.easeInOut(startY, endY, (enter + hold + n) / total));
  }

  private easeIn(a: number, b: number, p: number) { return a + (b - a) * Math.pow(p, 2); }
  private easeInOut(a: number, b: number, p: number) { return a + (b - a) * (-Math.cos(p * Math.PI) / 2 + 0.5); }

  private straight(n: number) { this.addRoad(n, n, n, 0, 0); }
  private curve(n: number, c: number, h: number) { this.addRoad(n, n, n, c, h); }
  private hill(n: number, h: number) { this.addRoad(n, n, n, 0, h); }
  private sCurve() { this.addRoad(10, 10, 10, -2.2, 0); this.addRoad(10, 10, 10, 3.0, -12); this.addRoad(10, 10, 10, -1.6, 8); }

  // ---------------- Scenery placement ----------------
  private placeScenery() {
    const neonColors = ["#ff2d95", "#00f0ff", "#fde047", "#a855f7", "#22c55e", "#fb923c"];
    const billboardTexts = ["NEON", "SPEED", "BOOST", "RACE", "TURBO", "DRIFT", "NITRO"];
    const n = this.segments.length;
    // lamp posts every ~6 segments on both sides for consistent lighting
    for (let i = 0; i < n; i += 6) {
      const seg = this.segments[i];
      const col = neonColors[i % neonColors.length];
      seg.scenery.push({ kind: "lamp", side: -1, offset: 1.35, color: col, variant: 0 });
      seg.scenery.push({ kind: "lamp", side: 1, offset: 1.35, color: neonColors[(i + 3) % neonColors.length], variant: 0 });
    }
    // palms every ~9 segments alternating sides
    for (let i = 3; i < n; i += 9) {
      const seg = this.segments[i];
      const side: -1 | 1 = (i % 18 < 9) ? -1 : 1;
      seg.scenery.push({ kind: "palm", side, offset: 1.6, color: "#1e3a2e", variant: i % 3 });
    }
    // neon billboards every ~24 segments
    for (let i = 12; i < n; i += 24) {
      const seg = this.segments[i];
      const side: -1 | 1 = (i % 48 < 24) ? -1 : 1;
      seg.scenery.push({
        kind: "billboard",
        side,
        offset: 1.9,
        color: neonColors[i % neonColors.length],
        variant: i % billboardTexts.length,
      });
    }
    // start/finish arch
    if (this.segments[2]) {
      this.segments[2].scenery.push({ kind: "arch", side: -1, offset: 0, color: "#fde047", variant: 0 });
    }

    // turbo boost pads — clusters of 3-4 segments on straights/curve exits,
    // alternating sides so the player must commit to a racing line
    const padColors = ["#00f0ff", "#fde047", "#22c55e"];
    for (let i = 30; i < n - 20; i += 48) {
      const side = (Math.floor(i / 48) % 2 === 0) ? -0.4 : 0.4;
      const col = padColors[Math.floor(i / 48) % padColors.length];
      for (let k = 0; k < 4; k++) {
        const seg = this.segments[i + k];
        if (seg && !seg.pad) {
          seg.pad = {
            offset: side,
            width: 0.28,
            color: col,
            phase: k * 0.25,
          };
        }
      }
    }
  }

  reset() {
    this.segments = [];
    if (this.trackId === 6) {
      // Track 6 — "Crystal Peak": big elevation climbs/descents + sweeping curves,
      // rendered with snow weather effects by the renderer.
      this.straight(40);
      this.hill(50, 40);
      this.curve(45, 3.2, 8);
      this.hill(40, -32);
      this.curve(50, -4.0, 0);
      this.straight(30);
      this.hill(45, 36);
      this.sCurve();
      this.curve(40, 3.6, -14);
      this.hill(35, -28);
      this.curve(45, -3.0, 20);
      this.hill(40, 30);
      this.curve(35, 4.2, 0);
      this.straight(35);
      this.hill(30, -24);
      this.curve(40, -3.4, 10);
      this.straight(30);
    } else if (this.trackId === 5) {
      // Track 5 — "Neon Rain": medium-flowing with mixed elevation,
      // rendered with rain weather effects (streaks + wet shimmer) by the renderer.
      this.straight(55);
      this.curve(45, 3.0, 6);
      this.hill(35, 18);
      this.curve(40, -3.6, -8);
      this.straight(30);
      this.curve(50, 4.2, 14);
      this.hill(35, -16);
      this.sCurve();
      this.curve(40, -3.0, 10);
      this.hill(40, 22);
      this.curve(35, 3.8, -6);
      this.straight(35);
      this.curve(45, -4.4, 0);
      this.hill(30, -20);
      this.curve(40, 2.8, 12);
      this.straight(30);
    } else if (this.trackId === 4) {
      // Track 4 — "Neon Tunnel": tight technical curves, flat elevation,
      // rendered as an enclosed tunnel by the renderer (trackId === 4 flag).
      this.straight(50);
      this.curve(40, 3.8, 0);
      this.curve(30, -4.4, 0);
      this.straight(25);
      this.sCurve();
      this.curve(45, 5.0, 0);
      this.straight(20);
      this.curve(35, -3.6, 0);
      this.sCurve();
      this.curve(40, 4.2, 0);
      this.straight(30);
      this.curve(45, -4.8, 0);
      this.curve(30, 3.4, 0);
      this.sCurve();
      this.straight(35);
      this.curve(40, -4.0, 0);
      this.straight(25);
    } else if (this.trackId === 3) {
      // Track 3 — "Sunset Coast": long flowing sweepers + big elevation
      this.straight(60);
      this.curve(60, 2.8, 8);
      this.hill(50, 36);
      this.curve(50, -3.4, 0);
      this.straight(40);
      this.curve(45, 4.0, -22);
      this.hill(40, 30);
      this.straight(35);
      this.curve(55, -2.6, 18);
      this.curve(45, 3.2, -10);
      this.hill(35, -28);
      this.curve(40, -3.8, 0);
      this.straight(45);
      this.hill(30, 26);
      this.curve(40, 2.4, -14);
      this.straight(35);
    } else if (this.trackId === 2) {
      // Track 2 — "Twilight Spires": tighter, hillier, more technical
      this.straight(40);
      this.curve(30, 3.6, 0);
      this.hill(40, 30);
      this.curve(30, -4.2, -14);
      this.sCurve();
      this.hill(30, 22);
      this.curve(45, 4.6, 10);
      this.straight(25);
      this.curve(35, -5.2, -20);
      this.hill(35, 28);
      this.sCurve();
      this.curve(40, 3.8, 12);
      this.hill(30, -24);
      this.curve(35, -4.4, 16);
      this.straight(30);
    } else {
      // Track 1 — "Neon Circuit": the original flowing layout
      this.straight(90);
      this.hill(30, 20);
      this.straight(30);
      this.curve(40, 3.2, 0);
      this.hill(30, -18);
      this.sCurve();
      this.straight(40);
      this.curve(50, -4.0, 16);
      this.hill(40, 24);
      this.straight(30);
      this.curve(35, 2.4, -10);
      this.curve(35, -2.8, 14);
      this.straight(50);
      this.hill(30, -20);
      this.curve(45, 3.6, 0);
      this.straight(40);
    }
    // close loop: smooth back to start height
    this.addRoad(20, 20, 20, 0, -this.lastY());

    for (const s of this.segments) { s.cars = []; s.scenery = []; s.pad = undefined; }
    this.trackLength = this.segments.length * SEGMENT_LENGTH;

    this.placeScenery();

    // mirror mode: flip all curve directions + swap scenery/pad sides
    if (this.mirror) {
      for (const s of this.segments) {
        s.curve = -s.curve;
        for (const sc of s.scenery) sc.side = (sc.side === -1 ? 1 : -1) as -1 | 1;
        if (s.pad) s.pad.offset = -s.pad.offset;
      }
    }

    // difficulty-scaled AI speeds
    const diffMul =
      this.difficulty === "easy" ? 0.78 : this.difficulty === "hard" ? 1.02 : 0.9;

    // place 9 opponents spread around the track ahead of player
    this.cars = [];
    for (let i = 0; i < 9; i++) {
      const p = this.carPalette[i % this.carPalette.length];
      const car: Car = {
        offset: (Math.random() * 1.4 - 0.7),
        z: 3000 + i * 3400 + Math.random() * 300,
        speed: MAX_SPEED * (0.46 + Math.random() * 0.24) * diffMul,
        color: p.body,
        accent: p.accent,
        name: p.name,
        spin: 0,
        spinDir: 1,
        wobble: Math.random() * Math.PI * 2,
        laps: 0,
        finished: false,
      };
      this.cars.push(car);
    }

    // player
    this.playerX = 0;
    this.position = 0;
    this.speed = MAX_SPEED * 0.32; // rolling start so bumping is immediately fun
    this.steering = 0;
    this.nitro = 100;
    this.lap = 0;
    this.crashed = 0;
    this.shake = 0;
    this.onPad = false;
    this.combo = 0;
    this.comboTimer = 0;
    this.score = 0;
    this.padCooldown = 0;
    this.drifting = false;
    this.driftTimer = 0;
    this.driftScore = 0;
    this.driftCooldown = 0;
    // weather grip: wet track (5) has reduced grip
    this.grip = this.trackId === 5 ? 0.72 : 1;
    this.startTime = 0;
    this.currentTime = 0;
    this.lastLapTime = 0;
    this.lapSplits = [];
    this.raceState = "countdown";
    this.countdown = 3.2;
  }

  // ---------------- Helpers ----------------
  findSegment(z: number): Segment {
    const idx = Math.floor(z / SEGMENT_LENGTH) % this.segments.length;
    return this.segments[(idx + this.segments.length) % this.segments.length];
  }

  private interpolateHeight(a: number, b: number, p: number) {
    return a + (b - a) * p;
  }

  // ---------------- Simulation ----------------
  update(dt: number, input: GameInput) {
    if (this.raceState === "finished") {
      this.speed = Math.max(0, this.speed + DECEL * dt);
      this.position += this.speed * dt;
      this.updateCarsAI(dt);
      return;
    }

    if (this.raceState === "countdown") {
      this.countdown -= dt;
      if (this.countdown <= 0) {
        this.raceState = "racing";
        this.startTime = performance.now();
      }
      return;
    }

    const playerSeg = this.findSegment(this.position + PLAYER_Z);
    const speedPercent = this.speed / MAX_SPEED;

    // ----- steering (analog-aware, speed-balanced, with snappy return-to-center) -----
    const grip = this.grip;
    // determine the target steering input from analog or digital
    let target = input.steerAnalog ?? 0;
    if (target === 0) {
      // fall back to digital (keyboard)
      if (input.left) target -= 1;
      if (input.right) target += 1;
    }
    // amplify slightly for reduced grip (wet) — more slide/drift feel
    if (grip < 1) target *= 1.15;

    // smoothing: faster response toward input, snappier return to center
    const lerpRate = target === 0 ? STEER_RETURN_LERP : STEER_LERP;
    this.steering += (target - this.steering) * Math.min(1, dt * lerpRate);

    // steering authority: blend a floor (so low speed can still turn) with a
    // speed-scaled component (less authority at very high speed = less twitchy)
    const steerAuthority =
      STEER_MIN + (STEER_MAX - STEER_MIN) * (1 - speedPercent * STEER_SPEED_FALLOFF);
    this.playerX += this.steering * steerAuthority * dt;

    // centrifugal pull on curves (stronger when grip is low)
    this.playerX -= steerAuthority * playerSeg.curve * CENTRIFUGAL * (1 + (1 - grip) * 0.8) * dt;

    // ----- acceleration (analog-aware) -----
    const throttle = input.accelAnalog ?? (input.accel ? 1 : 0);
    const brakeInput = input.brakeAnalog ?? (input.brake ? 1 : 0);
    let accel = DECEL;
    if (throttle > 0) accel = ACCEL * throttle;
    if (brakeInput > 0) accel = BRAKING * brakeInput * (grip < 1 ? 0.7 : 1); // weaker brakes when wet

    let nitroMul = 1;
    if (input.nitro && this.nitro > 0) {
      nitroMul = NITRO_BOOST;
      this.nitro = Math.max(0, this.nitro - NITRO_DRAIN * dt);
    } else {
      this.nitro = Math.min(100, this.nitro + NITRO_REGEN * dt);
    }

    this.speed += accel * nitroMul * dt;
    if (this.speed < 0) this.speed = 0;
    const cap = MAX_SPEED * (nitroMul > 1 ? NITRO_BOOST : 1);
    if (this.speed > cap) this.speed = cap;

    // ----- off-road -----
    if ((this.playerX < -1 || this.playerX > 1) && this.speed > OFF_ROAD_LIMIT) {
      this.speed += OFF_ROAD_DECEL * dt;
      // rumble bumpiness
      this.playerX += (Math.random() - 0.5) * 0.02;
    }

    this.playerX = Math.max(-2.4, Math.min(2.4, this.playerX));

    // ----- turbo pads -----
    if (this.padCooldown > 0) this.padCooldown -= dt;
    this.onPad = false;
    const playerSegNow = this.findSegment(this.position + PLAYER_Z);
    if (playerSegNow.pad && this.padCooldown <= 0) {
      const pad = playerSegNow.pad;
      if (Math.abs(this.playerX - pad.offset) < pad.width + 0.06) {
        // hit a turbo pad — big speed kick + combo
        this.onPad = true;
        this.speed = Math.min(MAX_SPEED * 1.35, this.speed + MAX_SPEED * 0.35);
        this.nitro = Math.min(100, this.nitro + 14);
        this.padCooldown = 0.45;
        this.addCombo(1, "TURBO!");
        this._justTurbo = true;
      }
    }

    // ----- drift detection (opposite-lock steering at speed) -----
    // Drift = steering into the turn while the car is already moving sideways
    // (steering direction opposes lateral velocity on curves) at high speed.
    if (this.driftCooldown > 0) this.driftCooldown -= dt;
    const lateralVel = this.steering * steerStrength; // intended lateral motion
    const curvePush = steerStrength * playerSeg.curve * CENTRIFUGAL; // curve push
    // opposite-lock: steering one way while the curve pushes the other way
    const isOppositeLock =
      Math.abs(playerSeg.curve) > 0.5 &&
      Math.sign(this.steering) !== Math.sign(playerSeg.curve) &&
      Math.abs(this.steering) > 0.3;
    const fastEnough = this.speed > MAX_SPEED * 0.45;
    const wasDrifting = this.drifting;
    if ((isOppositeLock || (Math.abs(lateralVel) > 1.2 && fastEnough)) && fastEnough && this.driftCooldown <= 0) {
      this.drifting = true;
      this.driftTimer += dt;
      this.driftScore += Math.round(dt * 60 * (this.speed / MAX_SPEED) * 5);
    } else {
      if (wasDrifting) {
        // drift ended — bank the accumulated drift score as a combo if long enough
        if (this.driftTimer > 0.6 && this.driftScore > 30) {
          this.addCombo(1, "DRIFT!");
          this.score += this.driftScore;
          this._justDrift = true;
          this._driftBanked = this.driftScore;
        }
        this.drifting = false;
        this.driftTimer = 0;
        this.driftScore = 0;
        this.driftCooldown = 0.4;
      }
    }
    void curvePush;

    // ----- combo timer decay -----
    if (this.comboTimer > 0) {
      this.comboTimer -= dt;
      if (this.comboTimer <= 0) {
        this.combo = 0;
        this.comboTimer = 0;
      }
    }

    // ----- advance position + lap -----
    this.position += this.speed * dt;
    while (this.position >= this.trackLength) {
      this.position -= this.trackLength;
      this.lap++;
      const lapSplit = this.currentTime - this.lastLapTime;
      this.lapSplits.push(lapSplit);
      this.lastLapTime = this.currentTime;
      this._justLapped = true;
      if (this.bestLapTime === 0 || lapSplit < this.bestLapTime) {
        this.bestLapTime = lapSplit;
      }
      // ghost-beaten detection: if a ghost is loaded and this lap was faster
      if (this.ghostEnabled && this.ghostLapTime > 0 && lapSplit < this.ghostLapTime && lapSplit > 0.5) {
        this._justBeatGhost = true;
        this._ghostBeatenDelta = this.ghostLapTime - lapSplit; // how much faster
        this.score += 500; // bonus for beating the ghost
      }
      if (this.lap >= this.totalLaps) {
        this.raceState = "finished";
        if (this.bestTime === 0 || this.currentTime < this.bestTime) {
          this.bestTime = this.currentTime;
        }
      }
    }

    this.currentTime = (performance.now() - this.startTime) / 1000;

    // ----- live ghost-delta (player z vs ghost z at the same lap-elapsed time) -----
    // engine.ghost is set by the React layer from the GhostPlayer each frame.
    // Delta = player's unwrapped lap z minus ghost's z; positive = player ahead.
    if (this.ghost && this.ghostEnabled) {
      let pz = this.position;
      let gz = this.ghost.z;
      // both wrapped to [0, trackLength); compare directly
      let d = pz - gz;
      // normalize to shortest signed distance
      if (d > this.trackLength / 2) d -= this.trackLength;
      if (d < -this.trackLength / 2) d += this.trackLength;
      this.ghostDelta = d;
    } else {
      this.ghostDelta = 0;
    }

    // ----- collisions: player vs opponents -----
    this.handlePlayerCollisions();

    // ----- opponents AI -----
    this.updateCarsAI(dt);

    if (this.crashed > 0) this.crashed -= dt;
    if (this.shake > 0) this.shake = Math.max(0, this.shake - dt * 2.2);
    this._justBumped = false;
    this._justLapped = false;
    this._justTurbo = false;
    this._justDrift = false;
    this._justBeatGhost = false;
    this._ghostBeatenDelta = 0;
    this._driftBanked = 0;
    this._bumpPoint = null;
  }

  /** Add a combo action: increments combo, resets the decay timer, awards score. */
  addCombo(_delta: number, label: string) {
    this.combo += 1;
    this.comboTimer = 3.0; // 3s window to chain the next action
    const mult = Math.min(8, this.combo);
    this.score += 100 * mult;
    this._comboLabel = label;
  }

  // event flags consumed by the React layer (audio/particles), cleared each frame
  private _justBumped = false;
  private _justLapped = false;
  private _justTurbo = false;
  private _justDrift = false;
  private _justBeatGhost = false;
  private _ghostBeatenDelta = 0; // how much faster the player's lap was vs the ghost (set on beat)
  private _driftBanked = 0;
  private _comboLabel = "";
  get justBumped() { return this._justBumped; }
  get justLapped() { return this._justLapped; }
  get justTurbo() { return this._justTurbo; }
  get justDrift() { return this._justDrift; }
  get justBeatGhost() { return this._justBeatGhost; }
  get ghostBeatenDelta() { return this._ghostBeatenDelta; }
  get driftBanked() { return this._driftBanked; }
  get comboLabel() { return this._comboLabel; }

  private updateCarsAI(dt: number) {
    for (const car of this.cars) {
      if (car.finished) continue;
      car.wobble += dt * 8;

      if (car.spin > 0) {
        car.spin -= dt;
        car.offset += car.spinDir * dt * 1.2;   // drift outward
        car.speed = Math.max(0, car.speed - MAX_SPEED * 0.9 * dt);
        car.z += car.speed * dt;
      } else {
        // look ahead to steer with the curve
        const ahead = this.findSegment(car.z + SEGMENT_LENGTH * 6);
        const targetOffset = -ahead.curve * 0.18 + (car.offset * 0.4);
        car.offset += (targetOffset - car.offset) * Math.min(1, dt * 2);
        car.offset = Math.max(-0.95, Math.min(0.95, car.offset));
        car.z += car.speed * dt;
      }

      // wrap & lap
      while (car.z >= this.trackLength) {
        car.z -= this.trackLength;
        car.laps++;
      }
      while (car.z < 0) car.z += this.trackLength;
    }
  }

  private handlePlayerCollisions() {
    const playerWorldZ = (this.position + PLAYER_Z) % this.trackLength;
    for (const car of this.cars) {
      // skip cars already spinning from a previous bump (prevents multi-frame
      // speed loss on the same opponent)
      if (car.spin > 0) continue;

      let dz = car.z - playerWorldZ;
      if (dz > this.trackLength / 2) dz -= this.trackLength;
      if (dz < -this.trackLength / 2) dz += this.trackLength;

      // collision zone: within ~1.0 segment in z and ~0.9 in x
      if (Math.abs(dz) < SEGMENT_LENGTH * 1.0) {
        const dx = car.offset - this.playerX;
        if (Math.abs(dx) < 0.9) {
          // arcade bump: the opponent always gets knocked off, player plows
          // through with just a mild scrub — satisfying takedown action.
          const sideHit = dx >= 0 ? -1 : 1;
          car.spin = 1.1;
          car.spinDir = sideHit;
          car.speed *= 0.4;
          this.speed *= 0.9;
          this.playerX += sideHit * 0.08;
          this.nitro = Math.min(100, this.nitro + BUMP_BOOST * 10);
          this.crashed = 0.16;
          this.shake = Math.max(this.shake, 0.6);
          this._justBumped = true;
          this._bumpPoint = { z: car.z, offset: car.offset };
          this.addCombo(1, "BUMP!");
        }
      }
    }
  }

  private _bumpPoint: { z: number; offset: number } | null = null;
  get bumpPoint() { return this._bumpPoint; }

  // ---------------- Projection ----------------
  project(p: Point3, camX: number, camY: number, camZ: number) {
    p.camera.x = p.world.x - camX;
    p.camera.y = p.world.y - camY;
    p.camera.z = p.world.z - camZ;
    p.screen.scale = CAMERA_DEPTH / p.camera.z;
    p.screen.x = Math.round(this.width / 2 + (p.screen.scale * p.camera.x * this.width) / 2);
    p.screen.y = Math.round(this.height / 2 - (p.screen.scale * p.camera.y * this.height) / 2);
    p.screen.w = Math.round((p.screen.scale * ROAD_WIDTH * this.width) / 2);
  }

  // ---------------- Read state for HUD / ranking ----------------
  getRenderState(): RenderState {
    const baseSegment = this.findSegment(this.position);
    const basePercent =
      (((this.position % SEGMENT_LENGTH) + SEGMENT_LENGTH) % SEGMENT_LENGTH) / SEGMENT_LENGTH;
    const playerZ = this.position + PLAYER_Z;
    const playerSegment = this.findSegment(playerZ);
    const playerPercent =
      (((playerZ % SEGMENT_LENGTH) + SEGMENT_LENGTH) % SEGMENT_LENGTH) / SEGMENT_LENGTH;
    const playerY = this.interpolateHeight(
      playerSegment.p1.world.y,
      playerSegment.p2.world.y,
      playerPercent
    );

    const progress = (car: Car) => car.laps * this.trackLength + car.z;
    const ranked = this.cars.map((c) => ({ car: c, isPlayer: false }));
    ranked.push({
      car: {
        offset: this.playerX,
        z: playerZ % this.trackLength,
        speed: this.speed,
        color: "#3b82f6",
        accent: "#fde047",
        name: "YOU",
        spin: 0,
        spinDir: 1,
        wobble: 0,
        laps: this.lap,
        finished: this.raceState === "finished",
      } as Car,
      isPlayer: true,
    });
    ranked.sort((a, b) => progress(b.car) - progress(a.car));

    return {
      baseSegmentIndex: baseSegment.index,
      basePercent,
      playerY,
      playerSegmentIndex: playerSegment.index,
      playerPercent,
      speedPercent: this.speed / MAX_SPEED,
      rankedCars: ranked,
      position: ranked.findIndex((r) => r.isPlayer) + 1,
    };
  }
}
