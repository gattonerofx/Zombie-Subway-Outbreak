// ============================================================================
// NEON RACER — Leaderboard (localStorage persistence)
// Stores best lap time + best score per track/difficulty. No deps.
// ============================================================================

export interface LeaderboardEntry {
  bestLap: number;   // seconds (0 = none yet)
  bestScore: number; // points
  bestTotal: number; // seconds (0 = none yet)
  initials?: string; // 3-letter player initials (optional)
}

export type LeaderboardMap = Record<string, LeaderboardEntry>;

const KEY = "neon-racer-leaderboard-v1";

function keyFor(trackId: number, difficulty: string, mirror: boolean) {
  return `t${trackId}-${difficulty}${mirror ? "-m" : ""}`;
}

export function loadLeaderboard(): LeaderboardMap {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return {};
    return JSON.parse(raw) as LeaderboardMap;
  } catch {
    return {};
  }
}

export function saveLeaderboard(data: LeaderboardMap) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    // ignore quota / privacy errors
  }
}

/** Record a race result; returns the updated entry + whether a record was set. */
export function recordResult(
  trackId: number,
  difficulty: string,
  mirror: boolean,
  result: { bestLap: number; score: number; bestTotal: number },
  initials?: string
): { entry: LeaderboardEntry; newLap: boolean; newScore: boolean; newTotal: boolean } {
  const data = loadLeaderboard();
  const k = keyFor(trackId, difficulty, mirror);
  const prev: LeaderboardEntry = data[k] || { bestLap: 0, bestScore: 0, bestTotal: 0 };
  const newLap = result.bestLap > 0 && (prev.bestLap === 0 || result.bestLap < prev.bestLap);
  const newScore = result.score > prev.bestScore;
  const newTotal = result.bestTotal > 0 && (prev.bestTotal === 0 || result.bestTotal < prev.bestTotal);
  const entry: LeaderboardEntry = {
    bestLap: newLap ? result.bestLap : prev.bestLap,
    bestScore: newScore ? result.score : prev.bestScore,
    bestTotal: newTotal ? result.bestTotal : prev.bestTotal,
    initials: initials || prev.initials || "",
  };
  data[k] = entry;
  saveLeaderboard(data);
  return { entry, newLap, newScore, newTotal };
}

export function getEntry(trackId: number, difficulty: string, mirror: boolean): LeaderboardEntry | null {
  const data = loadLeaderboard();
  return data[keyFor(trackId, difficulty, mirror)] || null;
}

/** Returns all stored entries as { trackId, difficulty, mirror, entry } for the leaderboard panel. */
export function getAllEntries(): { trackId: number; difficulty: string; mirror: boolean; entry: LeaderboardEntry }[] {
  const data = loadLeaderboard();
  const out: { trackId: number; difficulty: string; mirror: boolean; entry: LeaderboardEntry }[] = [];
  for (const [k, v] of Object.entries(data)) {
    const m = k.match(/^t(\d+)-([a-z]+)(-m)?$/);
    if (m) out.push({ trackId: Number(m[1]), difficulty: m[2], mirror: !!m[3], entry: v });
  }
  // sort by best lap time ascending (fastest first), entries with no lap go last
  out.sort((a, b) => {
    const aL = a.entry.bestLap || 9999;
    const bL = b.entry.bestLap || 9999;
    return aL - bL;
  });
  return out;
}
