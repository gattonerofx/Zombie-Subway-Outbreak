// ============================================================================
// NEON RACER — Particle System
// Lightweight pool-based particles: bump sparks, nitro flame trail, tire smoke,
// crash debris. Rendered in screen-space on the main canvas.
// ============================================================================

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  kind: "spark" | "smoke" | "flame" | "debris";
  gravity: number;
  rot: number;
  vr: number;
}

const MAX_PARTICLES = 260;

export class ParticleSystem {
  private particles: Particle[] = [];

  private push(p: Omit<Particle, "rot" | "vr"> & { rot?: number; vr?: number }) {
    if (this.particles.length >= MAX_PARTICLES) this.particles.shift();
    this.particles.push({
      ...p,
      rot: p.rot ?? 0,
      vr: p.vr ?? 0,
    } as Particle);
  }

  /** spawn sparks at a screen position (e.g. point of impact) */
  sparks(x: number, y: number, count = 14) {
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = 80 + Math.random() * 260;
      this.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 40,
        life: 0,
        maxLife: 0.4 + Math.random() * 0.4,
        size: 1.5 + Math.random() * 2.5,
        color: Math.random() < 0.5 ? "#fde047" : "#ff2d95",
        kind: "spark",
        gravity: 600,
      });
    }
  }

  /** spawn a nitro flame trail behind the player car */
  nitroTrail(x: number, y: number, w: number) {
    for (let i = 0; i < 3; i++) {
      this.push({
        x: x + (Math.random() - 0.5) * w * 0.5,
        y: y + Math.random() * 6,
        vx: (Math.random() - 0.5) * 40,
        vy: 120 + Math.random() * 80,
        life: 0,
        maxLife: 0.3 + Math.random() * 0.2,
        size: 4 + Math.random() * 5,
        color: Math.random() < 0.5 ? "#00f0ff" : "#ff2d95",
        kind: "flame",
        gravity: -20,
      });
    }
  }

  /** spawn tire smoke (off-road or hard drift) */
  smoke(x: number, y: number, count = 4) {
    for (let i = 0; i < count; i++) {
      this.push({
        x: x + (Math.random() - 0.5) * 20,
        y,
        vx: (Math.random() - 0.5) * 30,
        vy: -20 - Math.random() * 30,
        life: 0,
        maxLife: 0.6 + Math.random() * 0.5,
        size: 6 + Math.random() * 6,
        color: "#b8b8c8",
        kind: "smoke",
        gravity: -10,
      });
    }
  }

  /** spawn crash debris (car parts) flying off a bumped opponent */
  debris(x: number, y: number, color: string, count = 8) {
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = 100 + Math.random() * 320;
      this.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 120,
        life: 0,
        maxLife: 0.7 + Math.random() * 0.6,
        size: 3 + Math.random() * 5,
        color: Math.random() < 0.4 ? "#ffffff" : color,
        kind: "debris",
        gravity: 700,
        rot: Math.random() * Math.PI * 2,
        vr: (Math.random() - 0.5) * 14,
      });
    }
  }

  update(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life += dt;
      if (p.life >= p.maxLife) {
        this.particles.splice(i, 1);
        continue;
      }
      p.vy += p.gravity * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= 0.96;
      p.rot += p.vr * dt;
    }
  }

  render(ctx: CanvasRenderingContext2D) {
    ctx.save();
    for (const p of this.particles) {
      const t = 1 - p.life / p.maxLife;
      ctx.globalAlpha = t * (p.kind === "smoke" ? 0.4 : 0.9);
      if (p.kind === "flame") {
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 8;
      } else {
        ctx.shadowBlur = 0;
      }
      ctx.fillStyle = p.color;
      const s = p.size * (p.kind === "smoke" ? 1 + (1 - t) * 1.5 : t);
      if (p.kind === "debris") {
        // little rotating rectangles = car shards
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillRect(-s / 2, -s / 2, s, s * 0.6);
        ctx.restore();
      } else {
        ctx.beginPath();
        ctx.arc(p.x, p.y, s, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.globalAlpha = 1;
    ctx.shadowBlur = 0;
    ctx.restore();
  }

  clear() {
    this.particles.length = 0;
  }
}
