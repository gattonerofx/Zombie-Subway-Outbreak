// ============================================================================
// NEON RACER — Audio Engine (Web Audio API, no dependencies)
// Procedurally synthesized engine hum, tire screech, crash, nitro whoosh, UI blips.
// Lazily created on first user gesture (browser autoplay policy).
// ============================================================================

type SfxName = "bump" | "crash" | "nitro" | "click" | "start" | "lap" | "finish";

export class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;

  // engine loop nodes
  private engineOsc1: OscillatorNode | null = null;
  private engineOsc2: OscillatorNode | null = null;
  private engineGain: GainNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;

  // tire screech node
  private screechGain: GainNode | null = null;
  private screechSrc: AudioBufferSourceNode | null = null;

  // rain ambience node
  private rainGain: GainNode | null = null;
  private rainSrc: AudioBufferSourceNode | null = null;

  // reverb (tunnel) node — inserted between engine/screech and master when active
  private reverbNode: ConvolverNode | null = null;
  private reverbWet: GainNode | null = null;
  private reverbDry: GainNode | null = null;
  private reverbActive = false;
  // buses that feed through (dry) + (wet via reverb) → master
  private dryBus: GainNode | null = null;
  private wetBus: GainNode | null = null;

  enabled = true;
  private started = false;

  /** Must be called from a user gesture (click / keydown). */
  ensure() {
    if (this.started) {
      if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
      return;
    }
    try {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      this.ctx = new Ctx();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.5;
      this.master.connect(this.ctx.destination);
      // dry/wet bus structure for reverb
      this.dryBus = this.ctx.createGain();
      this.dryBus.gain.value = 1;
      this.dryBus.connect(this.master);
      this.wetBus = this.ctx.createGain();
      this.wetBus.gain.value = 0; // wet only audible when reverb active
      this.reverbNode = this.ctx.createConvolver();
      this.reverbNode.buffer = this.makeReverbImpulse(1.8);
      this.reverbWet = this.ctx.createGain();
      this.reverbWet.gain.value = 0.5;
      this.wetBus.connect(this.reverbNode);
      this.reverbNode.connect(this.reverbWet);
      this.reverbWet.connect(this.master);
      this.buildEngineLoop();
      this.buildScreech();
      this.buildRain();
      this.started = true;
    } catch {
      this.enabled = false;
    }
  }

  /** Generate a simple decaying-noise impulse response for the convolver reverb. */
  private makeReverbImpulse(duration: number): AudioBuffer {
    const ctx = this.ctx!;
    const rate = ctx.sampleRate;
    const len = Math.floor(rate * duration);
    const buf = ctx.createBuffer(2, len, rate);
    for (let ch = 0; ch < 2; ch++) {
      const data = buf.getChannelData(ch);
      for (let i = 0; i < len; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.5);
      }
    }
    return buf;
  }

  /** Connect a node to the dry bus (always) + wet bus (for reverb). */
  private connectToBuses(node: AudioNode) {
    if (this.dryBus) node.connect(this.dryBus);
    if (this.wetBus) node.connect(this.wetBus);
  }

  /** Enable/disable tunnel reverb (track 4). */
  setReverb(on: boolean) {
    if (!this.ctx || !this.reverbNode || !this.wetBus) return;
    if (on === this.reverbActive) return;
    this.reverbActive = on;
    const t = this.ctx.currentTime;
    this.wetBus.gain.setTargetAtTime(on ? 1 : 0, t, 0.1);
  }

  /** Set rain ambience volume (0 = off, 1 = full). */
  setRain(intensity: number) {
    if (!this.ctx || !this.rainGain) return;
    const v = Math.max(0, Math.min(0.18, intensity * 0.18));
    this.rainGain.gain.setTargetAtTime(v, this.ctx.currentTime, 0.2);
  }

  setEnabled(on: boolean) {
    this.enabled = on;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(on ? 0.5 : 0, this.ctx.currentTime, 0.05);
    }
  }

  // ---------------- engine loop ----------------
  private buildEngineLoop() {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    this.engineGain = ctx.createGain();
    this.engineGain.gain.value = 0.0;
    this.engineFilter = ctx.createBiquadFilter();
    this.engineFilter.type = "lowpass";
    this.engineFilter.frequency.value = 600;
    this.engineFilter.Q.value = 6;

    // two detuned saws for a richer engine tone
    this.engineOsc1 = ctx.createOscillator();
    this.engineOsc1.type = "sawtooth";
    this.engineOsc1.frequency.value = 60;
    this.engineOsc2 = ctx.createOscillator();
    this.engineOsc2.type = "square";
    this.engineOsc2.frequency.value = 90;
    this.engineOsc2.detune.value = 8;

    this.engineOsc1.connect(this.engineFilter);
    this.engineOsc2.connect(this.engineFilter);
    this.engineFilter.connect(this.engineGain);
    this.connectToBuses(this.engineGain);
    this.engineOsc1.start();
    this.engineOsc2.start();
  }

  /** Update engine pitch/volume from game speed (0..1+) and nitro state. */
  updateEngine(speedPercent: number, nitro: boolean, dt: number) {
    if (!this.ctx || !this.engineOsc1 || !this.engineOsc2 || !this.engineGain || !this.engineFilter)
      return;
    const t = this.ctx.currentTime;
    const p = Math.max(0, Math.min(1.6, speedPercent));
    const baseFreq = 55 + p * 230 + (nitro ? 40 : 0);
    const vol = 0.12 + p * 0.16;
    const cutoff = 500 + p * 2600 + (nitro ? 600 : 0);
    this.engineOsc1.frequency.setTargetAtTime(baseFreq, t, 0.05);
    this.engineOsc2.frequency.setTargetAtTime(baseFreq * 1.5, t, 0.05);
    this.engineGain.gain.setTargetAtTime(vol, t, 0.08);
    this.engineFilter.frequency.setTargetAtTime(cutoff, t, 0.08);
    void dt;
  }

  silenceEngine() {
    if (!this.ctx || !this.engineGain) return;
    this.engineGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.1);
  }

  // ---------------- tire screech (looping noise) ----------------
  private buildScreech() {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    // white noise buffer
    const buf = ctx.createBuffer(1, ctx.sampleRate * 1, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    this.screechSrc = ctx.createBufferSource();
    this.screechSrc.buffer = buf;
    this.screechSrc.loop = true;
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = 1800;
    bp.Q.value = 12;
    this.screechGain = ctx.createGain();
    this.screechGain.gain.value = 0;
    this.screechSrc.connect(bp);
    bp.connect(this.screechGain);
    this.connectToBuses(this.screechGain);
    this.screechSrc.start();
  }

  // ---------------- rain ambience (looping filtered noise) ----------------
  private buildRain() {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    // pink-ish noise buffer (1s loop)
    const buf = ctx.createBuffer(1, ctx.sampleRate * 1, ctx.sampleRate);
    const data = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < data.length; i++) {
      const white = Math.random() * 2 - 1;
      last = (last + 0.02 * white) / 1.02; // simple low-pass for pink-ish
      data[i] = last * 3;
    }
    this.rainSrc = ctx.createBufferSource();
    this.rainSrc.buffer = buf;
    this.rainSrc.loop = true;
    const lp = ctx.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 2400;
    this.rainGain = ctx.createGain();
    this.rainGain.gain.value = 0;
    this.rainSrc.connect(lp);
    lp.connect(this.rainGain);
    this.rainGain.connect(this.master);
    this.rainSrc.start();
  }

  /** intensity 0..1 — tire screech when drifting/off-road/hard turning at speed */
  setScreech(intensity: number) {
    if (!this.ctx || !this.screechGain) return;
    const v = Math.max(0, Math.min(0.22, intensity * 0.22));
    this.screechGain.gain.setTargetAtTime(v, this.ctx.currentTime, 0.05);
  }

  // ---------------- one-shot SFX ----------------
  play(name: SfxName) {
    if (!this.ctx || !this.master || !this.enabled) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    switch (name) {
      case "bump":
        this.tone(180, 80, 0.18, 0.3, "square", t);
        this.noiseBurst(0.12, 0.25, 1200, t);
        break;
      case "crash":
        this.noiseBurst(0.4, 0.5, 800, t);
        this.tone(90, 40, 0.4, 0.4, "sawtooth", t);
        break;
      case "nitro":
        // rising whoosh
        this.sweep(300, 1400, 0.35, 0.18, t);
        break;
      case "click":
        this.tone(660, 660, 0.05, 0.12, "square", t);
        break;
      case "start":
        this.tone(440, 440, 0.12, 0.2, "square", t);
        this.tone(660, 660, 0.18, 0.2, "square", t + 0.12);
        this.tone(880, 880, 0.25, 0.22, "square", t + 0.3);
        break;
      case "lap":
        this.tone(880, 1320, 0.18, 0.2, "triangle", t);
        break;
      case "finish":
        this.tone(523, 523, 0.15, 0.22, "square", t);
        this.tone(659, 659, 0.15, 0.22, "square", t + 0.15);
        this.tone(784, 784, 0.15, 0.22, "square", t + 0.3);
        this.tone(1047, 1047, 0.4, 0.25, "square", t + 0.45);
        break;
    }
  }

  private tone(
    fStart: number,
    fEnd: number,
    dur: number,
    vol: number,
    type: OscillatorType,
    when: number
  ) {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(fStart, when);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, fEnd), when + dur);
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(vol, when + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    osc.connect(g);
    this.connectToBuses(g);
    osc.start(when);
    osc.stop(when + dur + 0.02);
  }

  private sweep(fStart: number, fEnd: number, dur: number, vol: number, when: number) {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    const f = ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.setValueAtTime(fStart * 2, when);
    f.frequency.exponentialRampToValueAtTime(fEnd * 3, when + dur);
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(fStart, when);
    osc.frequency.exponentialRampToValueAtTime(fEnd, when + dur);
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(vol, when + 0.05);
    g.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    osc.connect(f);
    f.connect(g);
    this.connectToBuses(g);
    osc.start(when);
    osc.stop(when + dur + 0.02);
  }

  private noiseBurst(dur: number, vol: number, cutoff: number, when: number) {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const buf = ctx.createBuffer(1, ctx.sampleRate * dur, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const f = ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = cutoff;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, when);
    g.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    src.connect(f);
    f.connect(g);
    this.connectToBuses(g);
    src.start(when);
    src.stop(when + dur + 0.02);
  }
}
