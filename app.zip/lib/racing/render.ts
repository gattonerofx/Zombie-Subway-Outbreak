// ============================================================================
// NEON RACER — Renderer
// All canvas drawing: neon sky/city, pseudo-3D road, low-poly cars,
// and three camera views (chase / hood / cockpit with steering wheel).
// ============================================================================

import {
  GameEngine,
  ROAD_WIDTH,
  SEGMENT_LENGTH,
  DRAW_DISTANCE,
  FOG_DENSITY,
  CAMERA_HEIGHT,
  CAMERA_DEPTH,
  PLAYER_Z,
  LANES,
  type RenderState,
  type Car,
  type CarSprite,
  type ScenerySprite,
} from "./engine";
import { ParticleSystem } from "./particles";

// ----- Road color palette (neon night) -----
const ROAD = { light: "#2a2a44", dark: "#23233c" };
const GRASS = { light: "#080814", dark: "#05050d" };
const RUMBLE = { light: "#ff2d95", dark: "#f4f4fb" }; // pink / white
const LANE = "#e8e8f5";

interface Star { x: number; y: number; r: number; a: number; tw: number; }
interface Building { w: number; h: number; windows: boolean[]; }

export class Renderer {
  private stars: Star[] = [];
  private buildings: Building[] = [];
  private citySeed = 0;
  readonly particles = new ParticleSystem();
  reducedMotion = false; // when true, skip screen-shake + scanlines

  constructor() {
    // precompute starfield
    for (let i = 0; i < 160; i++) {
      this.stars.push({
        x: Math.random(),
        y: Math.random() * 0.55,
        r: Math.random() * 1.4 + 0.3,
        a: Math.random() * 0.7 + 0.3,
        tw: Math.random() * Math.PI * 2,
      });
    }
    // precompute city silhouette band (stable pseudo-random)
    let x = 0;
    while (x < 4000) {
      const w = 40 + Math.random() * 90;
      const h = 30 + Math.random() * 130;
      const cols = Math.max(2, Math.floor(w / 14));
      const rows = Math.max(3, Math.floor(h / 16));
      const windows: boolean[] = [];
      for (let i = 0; i < cols * rows; i++) windows.push(Math.random() < 0.32);
      this.buildings.push({ w, h, windows });
      x += w + 4;
    }
  }

  // ===================== main entry =====================
  render(ctx: CanvasRenderingContext2D, engine: GameEngine) {
    const rs = engine.getRenderState();
    const view = engine.view;

    // screen-shake offset (decays in engine.update); skipped in reduced-motion
    const shakeAmt = this.reducedMotion ? 0 : engine.shake;
    const sx = (Math.random() - 0.5) * shakeAmt * 18;
    const sy = (Math.random() - 0.5) * shakeAmt * 18;

    ctx.save();
    if (shakeAmt > 0.01) ctx.translate(sx, sy);

    // 1. sky + parallax horizon shift
    const horizonShift = this.computeHorizonShift(engine, rs);
    this.drawSky(ctx, engine, horizonShift);
    this.drawCity(ctx, engine, horizonShift);
    this.drawMoon(ctx, engine, horizonShift);

    // 2. road
    this.drawRoad(ctx, engine, rs);

    // 2.5 tunnel ceiling (track 4 only)
    if (engine.trackId === 4) this.drawTunnel(ctx, engine, rs);

    // 3. scenery (billboards, palms, lamps, arches)
    this.drawScenery(ctx, engine, rs);

    // 3.5 ghost car (translucent, behind live cars)
    this.drawGhost(ctx, engine, rs);

    // 4. sprites (cars + player)
    this.drawSprites(ctx, engine, rs, view);

    // 5. particles (sparks/smoke/flame) — above cars, below cockpit
    this.particles.render(ctx);

    // 6. view overlay
    if (view === "cockpit") this.drawCockpit(ctx, engine, rs);
    if (view === "hood") this.drawHoodOverlay(ctx, engine, rs);

    // 7. crash flash + speed vignette + scanlines (scanlines skipped in reduced-motion)
    this.drawVignette(ctx, engine, rs);
    if (!this.reducedMotion) this.drawScanlines(ctx, engine);

    // 8. weather overlay (rain track 5, snow track 6)
    if (engine.trackId === 5) this.drawRain(ctx, engine);
    if (engine.trackId === 6) this.drawSnow(ctx, engine);

    ctx.restore();
  }

  // ---------- horizon parallax ----------
  private computeHorizonShift(engine: GameEngine, rs: RenderState): number {
    let shift = 0;
    let dx = -(engine.findSegment(engine.position).curve * rs.basePercent);
    for (let n = 0; n < 60; n++) {
      const seg = engine.segments[(rs.baseSegmentIndex + n) % engine.segments.length];
      shift += dx;
      dx += seg.curve;
    }
    return shift;
  }

  // ===================== sky =====================
  private drawSky(ctx: CanvasRenderingContext2D, e: GameEngine, shift: number) {
    const { width: w, height: h } = e;
    const g = ctx.createLinearGradient(0, 0, 0, h * 0.62);
    g.addColorStop(0, "#06061a");
    g.addColorStop(0.45, "#0d0826");
    g.addColorStop(0.8, "#1a0a2e");
    g.addColorStop(1, "#2a0e3a");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h * 0.62);

    // horizon glow band
    const glow = ctx.createLinearGradient(0, h * 0.45, 0, h * 0.62);
    glow.addColorStop(0, "rgba(255,45,149,0)");
    glow.addColorStop(0.6, "rgba(255,45,149,0.10)");
    glow.addColorStop(1, "rgba(0,240,255,0.16)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, h * 0.45, w, h * 0.18);

    // stars
    const t = performance.now() / 1000;
    for (const s of this.stars) {
      const sx = (s.x * w + shift * 0.15) % w;
      const x = sx < 0 ? sx + w : sx;
      const tw = 0.55 + Math.sin(t * 1.6 + s.tw) * 0.45;
      ctx.globalAlpha = s.a * tw;
      ctx.fillStyle = "#cfe8ff";
      ctx.fillRect(x, s.y * h, s.r, s.r);
    }
    ctx.globalAlpha = 1;
  }

  private drawMoon(ctx: CanvasRenderingContext2D, e: GameEngine, shift: number) {
    const { width: w, height: h } = e;
    const mx = (w * 0.74 + shift * 0.1) % (w + 200);
    const x = mx < 0 ? mx + w + 200 : mx;
    const y = h * 0.16;
    const r = Math.min(w, h) * 0.06;
    // glow
    const g = ctx.createRadialGradient(x, y, r * 0.3, x, y, r * 3);
    g.addColorStop(0, "rgba(255,220,240,0.55)");
    g.addColorStop(1, "rgba(255,220,240,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, r * 3, 0, Math.PI * 2);
    ctx.fill();
    // disc
    ctx.fillStyle = "#ffe9f3";
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "rgba(200,160,190,0.4)";
    ctx.beginPath();
    ctx.arc(x + r * 0.3, y - r * 0.2, r * 0.22, 0, Math.PI * 2);
    ctx.arc(x - r * 0.25, y + r * 0.25, r * 0.16, 0, Math.PI * 2);
    ctx.fill();
  }

  // ===================== city silhouette =====================
  private drawCity(ctx: CanvasRenderingContext2D, e: GameEngine, shift: number) {
    const { width: w, height: h } = e;
    const horizon = h * 0.6;
    const totalW = 4000;
    const off = ((shift * 0.5) % totalW + totalW) % totalW;

    // far layer (dim)
    this.drawCityLayer(ctx, e, off * 0.5, horizon, 0.55, "#0a0a18", "#1a1430");
    // near layer (brighter)
    this.drawCityLayer(ctx, e, off, horizon, 1, "#0e0a1c", "#241638");
  }

  private drawCityLayer(
    ctx: CanvasRenderingContext2D,
    e: GameEngine,
    off: number,
    horizon: number,
    scale: number,
    fill: string,
    windowGlow: string
  ) {
    const { width: w } = e;
    const band = 4000;
    for (let pass = 0; pass < 2; pass++) {
      let x = -off + pass * band;
      for (let bi = 0; bi < this.buildings.length; bi++) {
        const b = this.buildings[bi];
        const bw = b.w * scale;
        const bh = b.h * scale;
        const bx = x;
        if (bx + bw > -20 && bx < w + 20) {
          ctx.fillStyle = fill;
          ctx.fillRect(bx, horizon - bh, bw, bh);
          // windows
          const cols = Math.max(2, Math.floor(bw / 12));
          const rows = Math.max(3, Math.floor(bh / 12));
          const ww = (bw / cols) * 0.4;
          const wh = (bh / rows) * 0.4;
          const gx = bw / cols;
          const gy = bh / rows;
          ctx.fillStyle = windowGlow;
          for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
              const idx = (r * cols + c) % b.windows.length;
              if (b.windows[idx]) {
                ctx.fillRect(bx + c * gx + gx * 0.3, horizon - bh + r * gy + gy * 0.3, ww, wh);
              }
            }
          }
          // neon roof edge — alternate pink/cyan per building
          ctx.fillStyle = bi % 2 === 0 ? "#ff2d95" : "#00f0ff";
          ctx.globalAlpha = 0.55 * scale;
          ctx.fillRect(bx, horizon - bh - 1, bw, 2);
          ctx.globalAlpha = 1;
        }
        x += bw + 4 * scale;
      }
    }
  }

  // ===================== road =====================
  private drawRoad(ctx: CanvasRenderingContext2D, e: GameEngine, rs: RenderState) {
    const baseSegment = e.segments[rs.baseSegmentIndex];
    const basePercent = rs.basePercent;
    const playerY = rs.playerY;

    let maxy = e.height;
    let x = 0;
    let dx = -(baseSegment.curve * basePercent);

    // view-dependent camera height
    const camHeight = e.view === "hood" ? 460 : e.view === "cockpit" ? 820 : CAMERA_HEIGHT;

    for (let n = 0; n < DRAW_DISTANCE; n++) {
      const segment = e.segments[(baseSegment.index + n) % e.segments.length];
      segment.looped = segment.index < baseSegment.index;
      segment.fog = this.exponentialFog(n / DRAW_DISTANCE, FOG_DENSITY);
      segment.clip = maxy;
      segment.roadX = x; // store accumulated curve offset for sprite/scenery projection

      const camZ = e.position - (segment.looped ? e.trackLength : 0);
      e.project(
        segment.p1,
        e.playerX * ROAD_WIDTH - x,
        playerY + camHeight,
        camZ
      );
      e.project(
        segment.p2,
        e.playerX * ROAD_WIDTH - x - dx,
        playerY + camHeight,
        camZ
      );

      x += dx;
      dx += segment.curve;

      if (
        segment.p1.camera.z <= CAMERA_DEPTH ||
        segment.p2.screen.y >= segment.p1.screen.y ||
        segment.p2.screen.y >= maxy
      ) {
        continue;
      }

      this.renderSegment(ctx, e, segment, n);
      maxy = segment.p2.screen.y;
    }
  }

  private exponentialFog(distance: number, density: number) {
    return 1 / Math.pow(Math.E, distance * distance * density);
  }

  private renderSegment(ctx: CanvasRenderingContext2D, e: GameEngine, segment: any, n: number) {
    const p1 = segment.p1.screen;
    const p2 = segment.p2.screen;
    const colorSet = segment.color;
    const rumbleW1 = p1.w * 0.085;
    const rumbleW2 = p2.w * 0.085;
    const laneW1 = p1.w * 0.018;
    const laneW2 = p2.w * 0.018;

    // grass (full width band)
    ctx.fillStyle = GRASS[colorSet];
    ctx.fillRect(0, p2.y, e.width, p1.y - p2.y);

    // rumble strips
    this.polygon(ctx, p1.x - p1.w - rumbleW1, p1.y, p1.x - p1.w, p1.y, p2.x - p2.w, p2.y, p2.x - p2.w - rumbleW2, p2.y, RUMBLE[colorSet]);
    this.polygon(ctx, p1.x + p1.w + rumbleW1, p1.y, p1.x + p1.w, p1.y, p2.x + p2.w, p2.y, p2.x + p2.w + rumbleW2, p2.y, RUMBLE[colorSet]);

    // road
    this.polygon(ctx, p1.x - p1.w, p1.y, p1.x + p1.w, p1.y, p2.x + p2.w, p2.y, p2.x - p2.w, p2.y, ROAD[colorSet]);

    // lane dashes (only on light segments)
    if (colorSet === "light") {
      const lanes = LANES;
      for (let l = 1; l < lanes; l++) {
        const f1 = (l / lanes) * 2 - 1;
        const f2 = f1;
        const lx1 = p1.x + p1.w * f1;
        const lx2 = p2.x + p2.w * f2;
        this.polygon(
          ctx,
          lx1 - laneW1, p1.y, lx1 + laneW1, p1.y,
          lx2 + laneW2, p2.y, lx2 - laneW2, p2.y,
          LANE
        );
      }
    }

    // turbo boost pad on this segment
    if (segment.pad) {
      const pad = segment.pad;
      const t = performance.now() / 1000;
      const pulse = 0.55 + Math.sin(t * 6 + pad.phase) * 0.45;
      const padW1 = p1.w * pad.width;
      const padW2 = p2.w * pad.width;
      const cx1 = p1.x + p1.w * pad.offset;
      const cx2 = p2.x + p2.w * pad.offset;
      // glow base
      ctx.save();
      ctx.globalAlpha = 0.35 + pulse * 0.5;
      ctx.fillStyle = pad.color;
      ctx.shadowColor = pad.color;
      ctx.shadowBlur = 18;
      this.polygon(ctx, cx1 - padW1, p1.y, cx1 + padW1, p1.y, cx2 + padW2, p2.y, cx2 - padW2, p2.y, pad.color);
      ctx.restore();
      // bright chevron arrows
      ctx.save();
      ctx.globalAlpha = 0.8 + pulse * 0.2;
      ctx.fillStyle = "#ffffff";
      const midY = (p1.y + p2.y) / 2;
      const midX = (cx1 + cx2) / 2;
      const aw = Math.max(2, padW1 * 0.7);
      const ah = Math.max(2, (p1.y - p2.y) * 0.4);
      ctx.beginPath();
      ctx.moveTo(midX, midY - ah);
      ctx.lineTo(midX + aw, midY);
      ctx.lineTo(midX, midY + ah);
      ctx.lineTo(midX - aw, midY);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }

    // fog overlay per segment
    if (segment.fog < 1) {
      ctx.globalAlpha = 1 - segment.fog;
      ctx.fillStyle = "#06061a";
      ctx.fillRect(0, p2.y, e.width, p1.y - p2.y);
      ctx.globalAlpha = 1;
    }
  }

  private polygon(
    ctx: CanvasRenderingContext2D,
    x1: number, y1: number,
    x2: number, y2: number,
    x3: number, y3: number,
    x4: number, y4: number,
    color: string
  ) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.lineTo(x3, y3);
    ctx.lineTo(x4, y4);
    ctx.closePath();
    ctx.fill();
  }

  // ===================== sprites =====================
  private drawSprites(ctx: CanvasRenderingContext2D, e: GameEngine, rs: RenderState, view: string) {
    const camHeight = view === "hood" ? 460 : view === "cockpit" ? 820 : CAMERA_HEIGHT;

    // gather visible cars with projection
    const sprites: CarSprite[] = [];
    for (const car of e.cars) {
      const sprite = this.projectCar(e, car, rs, camHeight);
      if (sprite) sprites.push(sprite);
    }

    // player sprite (chase view only): fixed at bottom center
    if (view === "chase") {
      const destW = (CAMERA_DEPTH / PLAYER_Z) * 0.0016 * e.width * e.width;
      const playerCar: Car = {
        offset: 0,
        z: e.position + PLAYER_Z,
        speed: e.speed,
        color: "#3b82f6",
        accent: "#fde047",
        name: "YOU",
        spin: e.crashed > 0 ? 0.3 : 0,
        spinDir: 1,
        wobble: e.crashed > 0 ? 12 : 0,
        laps: e.lap,
        finished: e.raceState === "finished",
      };
      sprites.push({
        sx: e.width / 2,
        sy: e.height * 0.94,
        destW: Math.max(120, destW * 0.0009 * e.width),
        car: playerCar,
        isPlayer: true,
        z: e.position + PLAYER_Z,
      });
    }

    // sort far -> near (draw far first)
    sprites.sort((a, b) => b.z - a.z);

    for (const s of sprites) {
      this.drawCarSprite(ctx, s.sx, s.sy, s.destW, s.car, !!s.isPlayer);
    }
  }

  private projectCar(
    e: GameEngine,
    car: Car,
    rs: RenderState,
    camHeight: number
  ): CarSprite | null {
    // depth relative to camera
    let dz = car.z - e.position;
    if (dz > e.trackLength / 2) dz -= e.trackLength;
    if (dz < -e.trackLength / 2) dz += e.trackLength;
    if (dz <= CAMERA_DEPTH) return null; // behind / too close

    // road height at the car
    const seg = e.findSegment(car.z);
    const yWorld = (seg.p1.world.y + seg.p2.world.y) / 2;
    const playerY = rs.playerY;
    // use the accumulated curve offset (roadX) so cars follow the road curve
    const curveOffset = seg.roadX;

    const scale = CAMERA_DEPTH / dz;
    const sx = e.width / 2 + (scale * (car.offset * ROAD_WIDTH - e.playerX * ROAD_WIDTH + curveOffset) * e.width) / 2;
    const sy = e.height / 2 - (scale * (yWorld - (playerY + camHeight)) * e.height) / 2;

    // size: a car occupies ~0.42 of the road half-width
    const destW = Math.max(14, scale * ROAD_WIDTH * 0.42 * e.width * 0.5);
    return { sx, sy, destW, car, z: car.z };
  }

  // ===================== car drawing (low-poly rear view) =====================
  private drawCarSprite(
    ctx: CanvasRenderingContext2D,
    cx: number,
    baseY: number,
    w: number,
    car: Car,
    isPlayer: boolean
  ) {
    const h = w * 0.72;
    const x = cx - w / 2;
    const y = baseY - h;

    ctx.save();

    // spin rotation when crashing; small shake on player bump
    let rot = 0;
    if (car.spin > 0) {
      rot = (1.1 - car.spin) * Math.PI * 2 * (car.spinDir > 0 ? 1 : -1);
    }
    if (isPlayer && car.wobble > 4) {
      rot = Math.sin(performance.now() / 30) * 0.12;
    }
    if (rot !== 0) {
      ctx.translate(cx, baseY - h / 2);
      ctx.rotate(rot);
      ctx.translate(-cx, -(baseY - h / 2));
    }

    // shadow
    ctx.fillStyle = "rgba(0,0,0,0.45)";
    ctx.beginPath();
    ctx.ellipse(cx, baseY + 2, w * 0.55, h * 0.12, 0, 0, Math.PI * 2);
    ctx.fill();

    // body lower (skirt)
    ctx.fillStyle = shade(car.color, -0.35);
    this.roundRect(ctx, x + w * 0.04, y + h * 0.45, w * 0.92, h * 0.5, w * 0.08);
    ctx.fill();

    // body main
    ctx.fillStyle = car.color;
    this.roundRect(ctx, x + w * 0.1, y + h * 0.18, w * 0.8, h * 0.5, w * 0.12);
    ctx.fill();

    // roof / cabin
    ctx.fillStyle = shade(car.color, -0.18);
    this.roundRect(ctx, x + w * 0.22, y + h * 0.06, w * 0.56, h * 0.32, w * 0.08);
    ctx.fill();

    // rear window (glass)
    const grad = ctx.createLinearGradient(0, y, 0, y + h * 0.3);
    grad.addColorStop(0, "#0b1220");
    grad.addColorStop(1, "#1b2a44");
    ctx.fillStyle = grad;
    this.roundRect(ctx, x + w * 0.26, y + h * 0.1, w * 0.48, h * 0.22, w * 0.04);
    ctx.fill();

    // spoiler
    ctx.fillStyle = shade(car.color, -0.5);
    ctx.fillRect(x + w * 0.06, y + h * 0.16, w * 0.88, h * 0.06);
    ctx.fillStyle = car.accent;
    ctx.fillRect(x + w * 0.06, y + h * 0.16, w * 0.88, h * 0.015);

    // taillights (glowing)
    const tl = w * 0.16;
    const tly = y + h * 0.5;
    this.glowRect(ctx, x + w * 0.14, tly, tl, h * 0.1, "#ff1e3c");
    this.glowRect(ctx, x + w * 0.7, tly, tl, h * 0.1, "#ff1e3c");

    // license / accent bar
    ctx.fillStyle = car.accent;
    ctx.fillRect(x + w * 0.42, y + h * 0.6, w * 0.16, h * 0.05);

    // wheels
    ctx.fillStyle = "#0a0a12";
    this.roundRect(ctx, x + w * 0.02, y + h * 0.55, w * 0.14, h * 0.3, w * 0.03);
    ctx.fill();
    this.roundRect(ctx, x + w * 0.84, y + h * 0.55, w * 0.14, h * 0.3, w * 0.03);
    ctx.fill();

    // player marker arrow
    if (isPlayer) {
      ctx.fillStyle = "#fde047";
      ctx.beginPath();
      ctx.moveTo(cx, y - h * 0.22);
      ctx.lineTo(cx - w * 0.1, y - h * 0.04);
      ctx.lineTo(cx + w * 0.1, y - h * 0.04);
      ctx.closePath();
      ctx.fill();
    }

    ctx.restore();
  }

  private glowRect(
    ctx: CanvasRenderingContext2D,
    x: number, y: number, w: number, h: number, color: string
  ) {
    ctx.save();
    ctx.shadowColor = color;
    ctx.shadowBlur = w * 0.6;
    ctx.fillStyle = color;
    this.roundRect(ctx, x, y, w, h, w * 0.2);
    ctx.fill();
    ctx.fillStyle = "#ffd0d8";
    this.roundRect(ctx, x + w * 0.2, y + h * 0.2, w * 0.6, h * 0.5, w * 0.1);
    ctx.fill();
    ctx.restore();
  }

  private roundRect(
    ctx: CanvasRenderingContext2D,
    x: number, y: number, w: number, h: number, r: number
  ) {
    const rr = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + rr, y);
    ctx.arcTo(x + w, y, x + w, y + h, rr);
    ctx.arcTo(x + w, y + h, x, y + h, rr);
    ctx.arcTo(x, y + h, x, y, rr);
    ctx.arcTo(x, y, x + w, y, rr);
    ctx.closePath();
  }

  // ===================== hood / cockpit overlays =====================
  private drawHoodOverlay(ctx: CanvasRenderingContext2D, e: GameEngine, _rs: RenderState) {
    const { width: w, height: h } = e;
    // subtle hood at very bottom
    const g = ctx.createLinearGradient(0, h * 0.8, 0, h);
    g.addColorStop(0, "rgba(10,10,25,0)");
    g.addColorStop(1, "rgba(10,10,25,0.85)");
    ctx.fillStyle = g;
    ctx.fillRect(0, h * 0.8, w, h * 0.2);
    // hood scoop hint
    ctx.fillStyle = "#15152a";
    this.roundRect(ctx, w * 0.36, h * 0.86, w * 0.28, h * 0.12, 8);
    ctx.fill();
    ctx.fillStyle = "#0a0a18";
    this.roundRect(ctx, w * 0.42, h * 0.9, w * 0.16, h * 0.05, 4);
    ctx.fill();
  }

  private drawCockpit(ctx: CanvasRenderingContext2D, e: GameEngine, rs: RenderState) {
    const { width: w, height: h } = e;

    // windshield dark frame top + A-pillars
    ctx.fillStyle = "#08080f";
    // top frame
    ctx.fillRect(0, 0, w, h * 0.06);
    // A-pillars (trapezoids)
    ctx.beginPath();
    ctx.moveTo(0, h * 0.06);
    ctx.lineTo(w * 0.16, h * 0.06);
    ctx.lineTo(w * 0.26, h * 0.6);
    ctx.lineTo(0, h * 0.6);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(w, h * 0.06);
    ctx.lineTo(w * 0.84, h * 0.06);
    ctx.lineTo(w * 0.74, h * 0.6);
    ctx.lineTo(w, h * 0.6);
    ctx.closePath();
    ctx.fill();

    // rearview mirror
    ctx.fillStyle = "#15151f";
    this.roundRect(ctx, w * 0.4, h * 0.02, w * 0.2, h * 0.05, 4);
    ctx.fill();
    ctx.fillStyle = "#1a2a3a";
    ctx.fillRect(w * 0.41, h * 0.03, w * 0.18, h * 0.03);

    // dashboard base
    const dashTop = h * 0.6;
    const dg = ctx.createLinearGradient(0, dashTop, 0, h);
    dg.addColorStop(0, "#0c0c16");
    dg.addColorStop(1, "#05050b");
    ctx.fillStyle = dg;
    ctx.beginPath();
    ctx.moveTo(0, dashTop);
    ctx.lineTo(w, dashTop);
    ctx.lineTo(w, h);
    ctx.lineTo(0, h);
    ctx.closePath();
    ctx.fill();

    // dash neon accent line
    ctx.fillStyle = "#00f0ff";
    ctx.globalAlpha = 0.6;
    ctx.fillRect(0, dashTop, w, 2);
    ctx.globalAlpha = 1;

    // left gauge (speed)
    this.drawGauge(ctx, w * 0.2, h * 0.8, Math.min(w, h) * 0.12, rs.speedPercent, "#00f0ff", "SPEED");
    // right gauge (nitro)
    this.drawGauge(ctx, w * 0.8, h * 0.8, Math.min(w, h) * 0.12, e.nitro / 100, "#ff2d95", "NITRO");

    // center digital readout
    ctx.fillStyle = "rgba(0,240,255,0.9)";
    ctx.font = `bold ${Math.round(h * 0.05)}px ui-monospace, monospace`;
    ctx.textAlign = "center";
    ctx.shadowColor = "#00f0ff";
    ctx.shadowBlur = 12;
    ctx.fillText(`${Math.round(rs.speedPercent * 320)}`, w / 2, h * 0.78);
    ctx.font = `${Math.round(h * 0.022)}px ui-monospace, monospace`;
    ctx.fillText("KM/H", w / 2, h * 0.82);
    ctx.shadowBlur = 0;

    // steering wheel
    this.drawSteeringWheel(ctx, w / 2, h * 0.9, Math.min(w, h) * 0.2, e.steering);

    // crash flash inside cockpit
    if (e.crashed > 0) {
      ctx.fillStyle = `rgba(255,30,60,${e.crashed * 1.2})`;
      ctx.fillRect(0, 0, w, h);
    }
  }

  private drawGauge(
    ctx: CanvasRenderingContext2D,
    cx: number, cy: number, r: number,
    value: number, color: string, label: string
  ) {
    // ring
    ctx.strokeStyle = "#1a1a2a";
    ctx.lineWidth = r * 0.18;
    ctx.beginPath();
    ctx.arc(cx, cy, r, Math.PI * 0.75, Math.PI * 2.25);
    ctx.stroke();
    // value arc
    ctx.strokeStyle = color;
    ctx.shadowColor = color;
    ctx.shadowBlur = 14;
    ctx.beginPath();
    ctx.arc(cx, cy, r, Math.PI * 0.75, Math.PI * 0.75 + Math.PI * 1.5 * Math.max(0, Math.min(1, value)));
    ctx.stroke();
    ctx.shadowBlur = 0;
    // label
    ctx.fillStyle = color;
    ctx.font = `bold ${Math.round(r * 0.22)}px ui-monospace, monospace`;
    ctx.textAlign = "center";
    ctx.fillText(label, cx, cy + r * 0.5);
  }

  private drawSteeringWheel(
    ctx: CanvasRenderingContext2D,
    cx: number, cy: number, r: number,
    steering: number
  ) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(steering * 1.3); // turn the wheel with steering input

    // outer rim
    ctx.strokeStyle = "#0a0a14";
    ctx.lineWidth = r * 0.26;
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, Math.PI * 2);
    ctx.stroke();

    // neon rim glow
    ctx.strokeStyle = "#ff2d95";
    ctx.lineWidth = r * 0.04;
    ctx.shadowColor = "#ff2d95";
    ctx.shadowBlur = 16;
    ctx.beginPath();
    ctx.arc(0, 0, r - r * 0.13, 0, Math.PI * 2);
    ctx.stroke();
    ctx.shadowBlur = 0;

    // spokes
    ctx.strokeStyle = "#15151f";
    ctx.lineWidth = r * 0.22;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, -r);
    ctx.moveTo(0, 0);
    ctx.lineTo(-r * 0.85, r * 0.5);
    ctx.moveTo(0, 0);
    ctx.lineTo(r * 0.85, r * 0.5);
    ctx.stroke();

    // center hub
    ctx.fillStyle = "#1a1a28";
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.26, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#00f0ff";
    ctx.lineWidth = r * 0.03;
    ctx.shadowColor = "#00f0ff";
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.26, 0, Math.PI * 2);
    ctx.stroke();
    ctx.shadowBlur = 0;

    // top marker (so rotation is visible)
    ctx.fillStyle = "#fde047";
    ctx.beginPath();
    ctx.arc(0, -r + r * 0.13, r * 0.06, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  // ===================== tunnel ceiling (track 4) =====================
  private drawTunnel(ctx: CanvasRenderingContext2D, e: GameEngine, rs: RenderState) {
    const baseSegment = e.segments[rs.baseSegmentIndex];
    const basePercent = rs.basePercent;
    let x = 0;
    let dx = -(baseSegment.curve * basePercent);
    const camHeight = CAMERA_HEIGHT;

    for (let n = 0; n < DRAW_DISTANCE; n++) {
      const segment = e.segments[(baseSegment.index + n) % e.segments.length];
      const looped = segment.index < baseSegment.index;
      const camZ = e.position - (looped ? e.trackLength : 0);
      // re-project p1/p2 for the ceiling (above the road)
      const p1 = segment.p1.screen;
      const p2 = segment.p2.screen;
      x += dx;
      dx += segment.curve;
      if (segment.p1.camera.z <= CAMERA_DEPTH) continue;
      if (p2.screen.y >= p1.screen.y) continue;

      // ceiling dome — a dark band above the road that follows its width
      const ceilY1 = p1.y - p1.w * 0.9;
      const ceilY2 = p2.y - p2.w * 0.9;
      const pulse = 0.5 + Math.sin(n * 0.5 + performance.now() / 200) * 0.5;
      // ceiling fill
      ctx.fillStyle = "#0a0612";
      ctx.beginPath();
      ctx.moveTo(p1.x - p1.w * 1.15, p1.y);
      ctx.lineTo(p1.x + p1.w * 1.15, p1.y);
      ctx.lineTo(p2.x + p2.w * 1.15, p2.y);
      ctx.lineTo(p2.x - p2.w * 1.15, p2.y);
      ctx.closePath();
      ctx.fill();
      // ceiling dome arc
      ctx.fillStyle = "#120a1e";
      ctx.beginPath();
      ctx.moveTo(p1.x - p1.w * 1.15, p1.y);
      ctx.quadraticCurveTo(p1.x, ceilY1, p1.x + p1.w * 1.15, p1.y);
      ctx.lineTo(p2.x + p2.w * 1.15, p2.y);
      ctx.quadraticCurveTo(p2.x, ceilY2, p2.x - p2.w * 1.15, p2.y);
      ctx.closePath();
      ctx.fill();
      // neon light strips along the ceiling apex
      const stripColor = n % 6 < 3 ? "#00f0ff" : "#ff2d95";
      ctx.fillStyle = stripColor;
      ctx.globalAlpha = 0.4 + pulse * 0.5;
      ctx.shadowColor = stripColor;
      ctx.shadowBlur = 12;
      const stripW1 = Math.max(1, p1.w * 0.04);
      const stripW2 = Math.max(1, p2.w * 0.04);
      this.polygon(ctx, p1.x - stripW1, ceilY1 + (p1.y - ceilY1) * 0.5, p1.x + stripW1, ceilY1 + (p1.y - ceilY1) * 0.5, p2.x + stripW2, ceilY2 + (p2.y - ceilY2) * 0.5, p2.x - stripW2, ceilY2 + (p2.y - ceilY2) * 0.5, stripColor);
      ctx.shadowBlur = 0;
      ctx.globalAlpha = 1;
      void camZ;
      void camHeight;
      void basePercent;
    }
  }

  // ===================== ghost car (best-lap replay) =====================
  private drawGhost(ctx: CanvasRenderingContext2D, e: GameEngine, rs: RenderState) {
    if (!e.ghost) return;
    const camHeight = e.view === "hood" ? 460 : e.view === "cockpit" ? 820 : CAMERA_HEIGHT;

    let dz = e.ghost.z - e.position;
    if (dz > e.trackLength / 2) dz -= e.trackLength;
    if (dz < -e.trackLength / 2) dz += e.trackLength;
    if (dz <= CAMERA_DEPTH) return; // behind camera

    const seg = e.findSegment(e.ghost.z);
    const yWorld = (seg.p1.world.y + seg.p2.world.y) / 2;
    const playerY = rs.playerY;
    // use the accumulated curve offset (roadX) so the ghost follows the road curve
    const curveOffset = seg.roadX;
    const scale = CAMERA_DEPTH / dz;
    const sx = e.width / 2 + (scale * (e.ghost.offset * ROAD_WIDTH - e.playerX * ROAD_WIDTH + curveOffset) * e.width) / 2;
    const sy = e.height / 2 - (scale * (yWorld - (playerY + camHeight)) * e.height) / 2;
    const destW = Math.max(14, scale * ROAD_WIDTH * 0.42 * e.width * 0.5);

    ctx.save();
    ctx.globalAlpha = 0.5;
    // ghost glow halo
    ctx.shadowColor = "#00f0ff";
    ctx.shadowBlur = 20;
    this.drawCarSprite(ctx, sx, sy, destW, {
      offset: e.ghost.offset,
      z: e.ghost.z,
      speed: 0,
      color: "#00f0ff",
      accent: "#ffffff",
      name: "GHOST",
      spin: 0,
      spinDir: 1,
      wobble: 0,
      laps: 0,
      finished: false,
    } as Car, false);
    ctx.restore();
  }

  // ===================== scenery (billboards, palms, lamps, arches) =====================
  private drawScenery(ctx: CanvasRenderingContext2D, e: GameEngine, rs: RenderState) {
    const camHeight = e.view === "hood" ? 460 : e.view === "cockpit" ? 820 : CAMERA_HEIGHT;
    const baseSegment = e.segments[rs.baseSegmentIndex];
    const sprites: ScenerySprite[] = [];

    for (let n = 0; n < DRAW_DISTANCE; n++) {
      const segment = e.segments[(baseSegment.index + n) % e.segments.length];
      if (!segment.scenery.length) continue;

      const looped = segment.index < baseSegment.index;
      let dz = segment.p1.world.z - e.position;
      if (looped) dz += e.trackLength;
      if (dz <= CAMERA_DEPTH) continue;

      const scale = CAMERA_DEPTH / dz;
      const yWorld = segment.p1.world.y;
      const playerY = rs.playerY;
      // use the accumulated curve offset (roadX) so scenery follows the road curve
      const curveOffset = segment.roadX;

      for (const item of segment.scenery) {
        const worldX = item.side * item.offset * ROAD_WIDTH;
        const sx =
          e.width / 2 + (scale * (worldX - e.playerX * ROAD_WIDTH + curveOffset) * e.width) / 2;
        const sy =
          e.height / 2 - (scale * (yWorld - (playerY + camHeight)) * e.height) / 2;
        sprites.push({
          ...item,
          sx,
          sy,
          scale,
          z: segment.p1.world.z + (looped ? e.trackLength : 0),
        });
      }
    }

    // far -> near
    sprites.sort((a, b) => b.z - a.z);
    for (const s of sprites) {
      this.drawSceneryItem(ctx, e, s);
    }
    void camHeight;
  }

  private drawSceneryItem(ctx: CanvasRenderingContext2D, e: GameEngine, s: ScenerySprite) {
    const baseH = s.scale * 2600 * e.height * 0.5;
    const w = s.scale * ROAD_WIDTH * e.width * 0.5;
    ctx.save();
    switch (s.kind) {
      case "lamp": {
        const h = baseH * 0.9;
        const poleW = Math.max(1, w * 0.04);
        ctx.fillStyle = "#0c0c18";
        ctx.fillRect(s.sx - poleW / 2, s.sy - h, poleW, h);
        // lamp head
        ctx.fillStyle = s.color;
        ctx.shadowColor = s.color;
        ctx.shadowBlur = 14;
        ctx.fillRect(s.sx - poleW, s.sy - h - poleW * 2, poleW * 2, poleW * 2);
        // light cone
        ctx.shadowBlur = 0;
        ctx.globalAlpha = 0.12;
        ctx.fillStyle = s.color;
        ctx.beginPath();
        ctx.moveTo(s.sx, s.sy - h);
        ctx.lineTo(s.sx - w * 0.5, s.sy);
        ctx.lineTo(s.sx + w * 0.5, s.sy);
        ctx.closePath();
        ctx.fill();
        ctx.globalAlpha = 1;
        break;
      }
      case "palm": {
        const h = baseH * 1.4;
        const trunkW = Math.max(1.5, w * 0.06);
        ctx.strokeStyle = "#0a1a12";
        ctx.lineWidth = trunkW;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(s.sx, s.sy);
        ctx.quadraticCurveTo(s.sx + trunkW * 2, s.sy - h * 0.6, s.sx, s.sy - h);
        ctx.stroke();
        // fronds
        ctx.strokeStyle = "#16432e";
        ctx.lineWidth = Math.max(1.5, trunkW * 1.4);
        for (let f = 0; f < 6; f++) {
          const ang = (f / 6) * Math.PI * 2;
          ctx.beginPath();
          ctx.moveTo(s.sx, s.sy - h);
          ctx.quadraticCurveTo(
            s.sx + Math.cos(ang) * h * 0.25,
            s.sy - h - Math.sin(ang) * h * 0.15,
            s.sx + Math.cos(ang) * h * 0.45,
            s.sy - h - Math.sin(ang) * h * 0.35
          );
          ctx.stroke();
        }
        break;
      }
      case "billboard": {
        const bh = baseH * 0.7;
        const bw = baseH * 1.2;
        const poleW = Math.max(1, w * 0.05);
        // poles
        ctx.fillStyle = "#0a0a16";
        ctx.fillRect(s.sx - bw * 0.4, s.sy - bh, poleW, bh);
        ctx.fillRect(s.sx + bw * 0.4 - poleW, s.sy - bh, poleW, bh);
        // panel
        ctx.fillStyle = "#06060f";
        ctx.fillRect(s.sx - bw / 2, s.sy - bh - bh * 0.8, bw, bh * 0.8);
        // neon border
        ctx.strokeStyle = s.color;
        ctx.lineWidth = Math.max(1, bw * 0.03);
        ctx.shadowColor = s.color;
        ctx.shadowBlur = 16;
        ctx.strokeRect(s.sx - bw / 2, s.sy - bh - bh * 0.8, bw, bh * 0.8);
        ctx.shadowBlur = 0;
        // text
        if (bh > 24) {
          const txt = e.billboardTexts[s.variant % e.billboardTexts.length];
          ctx.fillStyle = s.color;
          ctx.font = `900 ${Math.round(bh * 0.34)}px ui-monospace, monospace`;
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.shadowColor = s.color;
          ctx.shadowBlur = 10;
          ctx.fillText(txt, s.sx, s.sy - bh - bh * 0.4);
          ctx.shadowBlur = 0;
        }
        break;
      }
      case "arch": {
        // start/finish gantry spanning the road
        const h = baseH * 0.5;
        const span = w * 2;
        const poleW = Math.max(2, w * 0.06);
        ctx.fillStyle = "#0a0a16";
        ctx.fillRect(e.width / 2 - span, s.sy - h, poleW, h);
        ctx.fillRect(e.width / 2 + span - poleW, s.sy - h, poleW, h);
        // top beam with checkered + neon
        ctx.fillStyle = s.color;
        ctx.shadowColor = s.color;
        ctx.shadowBlur = 18;
        ctx.fillRect(e.width / 2 - span, s.sy - h, span * 2, Math.max(3, h * 0.08));
        ctx.shadowBlur = 0;
        // checker pattern
        const cells = 16;
        const cw = (span * 2) / cells;
        for (let i = 0; i < cells; i++) {
          ctx.fillStyle = i % 2 === 0 ? "#ffffff" : "#0a0a16";
          ctx.fillRect(e.width / 2 - span + i * cw, s.sy - h + h * 0.08, cw, h * 0.12);
        }
        break;
      }
    }
    ctx.restore();
  }

  // ===================== CRT scanlines =====================
  private drawScanlines(ctx: CanvasRenderingContext2D, e: GameEngine) {
    const { width: w, height: h } = e;
    ctx.save();
    ctx.globalAlpha = 0.06;
    ctx.fillStyle = "#000";
    for (let y = 0; y < h; y += 3) {
      ctx.fillRect(0, y, w, 1);
    }
    // subtle moving scan glow
    const t = (performance.now() / 18) % h;
    const g = ctx.createLinearGradient(0, t - 40, 0, t + 40);
    g.addColorStop(0, "rgba(0,240,255,0)");
    g.addColorStop(0.5, "rgba(0,240,255,0.04)");
    g.addColorStop(1, "rgba(0,240,255,0)");
    ctx.globalAlpha = 1;
    ctx.fillStyle = g;
    ctx.fillRect(0, t - 40, w, 80);
    ctx.restore();
  }

  // ===================== rain weather (track 5) =====================
  private drawRain(ctx: CanvasRenderingContext2D, e: GameEngine) {
    const { width: w, height: h } = e;
    const t = performance.now() / 1000;
    ctx.save();
    // wet-road shimmer: subtle horizontal cyan bands near the bottom
    ctx.globalAlpha = 0.08;
    ctx.fillStyle = "#00f0ff";
    for (let i = 0; i < 6; i++) {
      const yy = h * (0.62 + i * 0.05) + Math.sin(t * 2 + i) * 2;
      ctx.fillRect(0, yy, w, 1.5);
    }
    ctx.globalAlpha = 1;
    // rain streaks — diagonal lines falling, denser near bottom (perspective)
    ctx.strokeStyle = "rgba(180,220,255,0.45)";
    ctx.lineWidth = 1.2;
    const speed = 1 + e.speed / 3000; // rain falls faster as you go faster
    const streakLen = 14 + speed * 6;
    const count = 90;
    for (let i = 0; i < count; i++) {
      // pseudo-random stable positions
      const seed = i * 53.7;
      const baseX = (seed * 7.3 + t * 120 * speed) % (w + 80) - 40;
      const baseY = ((seed * 3.1 + t * 700 * speed) % (h + 40)) - 20;
      // skew by perspective: lower streaks are longer + more opaque
      const depth = baseY / h;
      if (depth < 0.3) continue; // above horizon, skip
      ctx.globalAlpha = 0.2 + depth * 0.5;
      ctx.beginPath();
      ctx.moveTo(baseX, baseY);
      ctx.lineTo(baseX - streakLen * 0.3, baseY + streakLen);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    ctx.restore();
  }

  // ===================== snow weather (track 6) =====================
  private drawSnow(ctx: CanvasRenderingContext2D, e: GameEngine) {
    const { width: w, height: h } = e;
    const t = performance.now() / 1000;
    ctx.save();
    // snowy road shimmer: subtle white-blue bands
    ctx.globalAlpha = 0.06;
    ctx.fillStyle = "#e0f2ff";
    for (let i = 0; i < 5; i++) {
      const yy = h * (0.6 + i * 0.06) + Math.sin(t * 1.5 + i) * 1.5;
      ctx.fillRect(0, yy, w, 1.5);
    }
    ctx.globalAlpha = 1;
    // snowflakes — slow drifting white dots with horizontal sway
    const count = 70;
    const speed = 1 + e.speed / 4000;
    for (let i = 0; i < count; i++) {
      const seed = i * 41.3;
      const baseX = (seed * 5.7 + Math.sin(t * 0.8 + i) * 30 + t * 25 * speed) % (w + 40) - 20;
      const baseY = ((seed * 2.9 + t * 180 * speed) % (h + 30)) - 15;
      const depth = baseY / h;
      if (depth < 0.25) continue;
      const size = 1 + depth * 2.5;
      ctx.globalAlpha = 0.3 + depth * 0.5;
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(baseX, baseY, size, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.restore();
  }

  // ===================== vignette / effects =====================
  private drawVignette(ctx: CanvasRenderingContext2D, e: GameEngine, rs: RenderState) {
    const { width: w, height: h } = e;
    // speed streaks at high speed
    const sp = rs.speedPercent;
    if (sp > 0.55) {
      ctx.globalAlpha = (sp - 0.55) * 0.5;
      ctx.strokeStyle = "rgba(255,255,255,0.5)";
      ctx.lineWidth = 1.5;
      const t = performance.now() / 40;
      for (let i = 0; i < 12; i++) {
        const seed = (i * 97 + Math.floor(t)) % 100;
        const side = i % 2 === 0 ? -1 : 1;
        const x = w / 2 + side * (w * 0.34 + (seed % 30));
        const y = (seed / 100) * h * 0.5 + h * 0.2;
        const len = 24 + sp * 60;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + side * len, y + len * 0.3);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
    }

    // crash flash (non-cockpit)
    if (e.crashed > 0 && e.view !== "cockpit") {
      ctx.fillStyle = `rgba(255,30,60,${e.crashed * 1.1})`;
      ctx.fillRect(0, 0, w, h);
    }

    // edge vignette
    const g = ctx.createRadialGradient(w / 2, h / 2, h * 0.3, w / 2, h / 2, h * 0.8);
    g.addColorStop(0, "rgba(0,0,0,0)");
    g.addColorStop(1, "rgba(0,0,0,0.45)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  }
}

// ----- color utils -----
function shade(hex: string, amt: number): string {
  const c = hex.replace("#", "");
  const r = parseInt(c.substring(0, 2), 16);
  const g = parseInt(c.substring(2, 4), 16);
  const b = parseInt(c.substring(4, 6), 16);
  const f = (v: number) => Math.max(0, Math.min(255, Math.round(v + 255 * amt)));
  return `rgb(${f(r)},${f(g)},${f(b)})`;
}
