// ============================================================================
// NEON RACER — Ghost Replay
// Records player (z, offset, speed) samples during a lap and replays them as
// a translucent ghost car to race against. Persisted to localStorage per track.
// ============================================================================

export interface GhostSample {
  z: number;       // track position (world units, unwrapped)
  offset: number;  // lateral -1..1
  speed: number;   // for visual reference
}

export interface GhostData {
  trackId: number;
  mirror: boolean;        // whether this ghost was recorded in mirror mode
  lapTime: number;        // seconds for the recorded lap
  samples: GhostSample[]; // one per ~100ms
}

const KEY = (trackId: number, mirror: boolean) => `neon-racer-ghost-t${trackId}${mirror ? "-m" : ""}`;

/** Load the best-lap ghost for a track (or null if none). */
export function loadGhost(trackId: number, mirror: boolean = false): GhostData | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(KEY(trackId, mirror));
    if (!raw) return null;
    return JSON.parse(raw) as GhostData;
  } catch {
    return null;
  }
}

/** Save a ghost if it's faster (or the first) for this track+mirror. */
export function saveGhostIfFaster(data: GhostData): boolean {
  if (typeof window === "undefined") return false;
  const prev = loadGhost(data.trackId, data.mirror);
  if (prev && prev.lapTime <= data.lapTime) return false; // not faster
  try {
    window.localStorage.setItem(KEY(data.trackId, data.mirror), JSON.stringify(data));
    return true;
  } catch {
    return false;
  }
}

/**
 * GhostRecorder: accumulates samples during a lap at a fixed interval.
 * Call record() each frame with the player's state; call finish() on lap end.
 */
export class GhostRecorder {
  private trackId: number;
  private mirror: boolean;
  private samples: GhostSample[] = [];
  private accumTime = 0;
  private lapTime = 0;
  private readonly interval = 0.1; // 100ms between samples (10 Hz)
  private lastZ = 0;
  private startZ = 0;
  private started = false;

  constructor(trackId: number, mirror: boolean = false) {
    this.trackId = trackId;
    this.mirror = mirror;
  }

  reset() {
    this.samples = [];
    this.accumTime = 0;
    this.lapTime = 0;
    this.started = false;
  }

  /** Record a frame. dt seconds, z wrapped to [0, trackLength). */
  record(dt: number, z: number, offset: number, speed: number, trackLength: number) {
    if (!this.started) {
      this.startZ = z;
      this.lastZ = z;
      this.started = true;
    }
    this.lapTime += dt;
    this.accumTime += dt;
    if (this.accumTime >= this.interval) {
      this.accumTime = 0;
      // unwrap z so samples are monotonically increasing
      let uz = z;
      if (uz < this.lastZ) uz += trackLength; // wrapped past the line
      this.samples.push({ z: uz, offset, speed });
      this.lastZ = uz;
    }
  }

  /** Finish the lap; returns the GhostData if valid, else null. */
  finish(): GhostData | null {
    if (this.samples.length < 5) return null;
    return {
      trackId: this.trackId,
      mirror: this.mirror,
      lapTime: this.lapTime,
      samples: this.samples,
    };
  }
}

/**
 * GhostPlayer: replays recorded samples at a given elapsed lap time.
 * Returns the interpolated (z, offset) or null if out of range.
 */
export class GhostPlayer {
  private data: GhostData;
  private idx = 0;

  constructor(data: GhostData) {
    this.data = data;
  }

  /** Get the ghost state at `elapsed` seconds into the lap. */
  sample(elapsed: number, trackLength: number): { z: number; offset: number } | null {
    const s = this.data.samples;
    if (s.length === 0) return null;
    // advance index to the sample just before `elapsed`
    while (this.idx + 1 < s.length && s[this.idx + 1].z <= 0) {
      this.idx++;
    }
    // binary-search-free linear advance (samples are ~100ms apart)
    // find the bracketing pair
    let i = Math.min(this.idx, s.length - 1);
    while (i + 1 < s.length && (i + 1) * 0.1 <= elapsed) i++;
    while (i > 0 && i * 0.1 > elapsed) i--;
    this.idx = i;
    if (i >= s.length - 1) {
      return { z: s[s.length - 1].z % trackLength, offset: s[s.length - 1].offset };
    }
    const t0 = i * 0.1;
    const t1 = (i + 1) * 0.1;
    const f = (elapsed - t0) / (t1 - t0 || 1);
    const z0 = s[i].z;
    const z1 = s[i + 1].z;
    const z = (z0 + (z1 - z0) * f) % trackLength;
    const offset = s[i].offset + (s[i + 1].offset - s[i].offset) * f;
    return { z, offset };
  }

  get lapTime() {
    return this.data.lapTime;
  }
  get sampleCount() {
    return this.data.samples.length;
  }
}
