"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { GameEngine, type GameInput, type ViewMode } from "@/lib/racing/engine";
import { Renderer } from "@/lib/racing/render";
import { AudioEngine } from "@/lib/racing/audio";
import { recordResult, getEntry, getAllEntries, type LeaderboardEntry } from "@/lib/racing/leaderboard";
import { GhostRecorder, GhostPlayer, loadGhost, saveGhostIfFaster } from "@/lib/racing/ghost";

type Screen = "menu" | "race";
type Difficulty = "easy" | "normal" | "hard";

interface StandingRow {
  name: string;
  color: string;
  isPlayer: boolean;
  spin: number;
  laps: number;
}
interface Results {
  finished: boolean;
  pos: number;
  time: number;
  best: number;
  score: number;
  splits: number[];
  bestLap: number;
}

const VIEWS: { id: ViewMode; label: string; hint: string }[] = [
  { id: "chase", label: "Chase", hint: "Behind the car" },
  { id: "hood", label: "Hood", hint: "First-person track" },
  { id: "cockpit", label: "Cockpit", hint: "Interior + wheel" },
];

const TRACKS: { id: 1 | 2 | 3 | 4 | 5 | 6; name: string; desc: string }[] = [
  { id: 1, name: "Neon Circuit", desc: "Flowing city sweep" },
  { id: 2, name: "Twilight Spires", desc: "Tight & technical" },
  { id: 3, name: "Sunset Coast", desc: "Long sweepers + hills" },
  { id: 4, name: "Neon Tunnel", desc: "Enclosed tunnel" },
  { id: 5, name: "Neon Rain", desc: "Wet weather race" },
  { id: 6, name: "Crystal Peak", desc: "Snowy mountain" },
];

const DIFFS: { id: Difficulty; label: string; desc: string }[] = [
  { id: "easy", label: "Easy", desc: "Slow rivals" },
  { id: "normal", label: "Normal", desc: "Balanced" },
  { id: "hard", label: "Hard", desc: "Faster rivals" },
];

// cache for leaderboard entry to keep object reference stable across renders
let _lbCache: { key: string; entry: LeaderboardEntry | null } | null = null;
function getCachedEntry(trackId: number, difficulty: string, lbVersion: number): LeaderboardEntry | null {
  const key = `${trackId}-${difficulty}-${lbVersion}`;
  if (_lbCache && _lbCache.key === key) return _lbCache.entry;
  const entry = getEntry(trackId, difficulty);
  _lbCache = { key, entry };
  return entry;
}

// project a world (z, offset) point to screen for particle placement
function projectImpact(
  engine: GameEngine,
  z: number,
  offset: number
): { x: number; y: number } | null {
  let dz = z - engine.position;
  if (dz > engine.trackLength / 2) dz -= engine.trackLength;
  if (dz < -engine.trackLength / 2) dz += engine.trackLength;
  if (dz <= 1) return null;
  // use the segment's accumulated curve offset so impact sparks follow the road curve
  const seg = engine.findSegment(z);
  const curveOffset = seg.roadX;
  const scale = (1 / Math.tan((50 * Math.PI) / 180)) / dz;
  const x = engine.width / 2 + (scale * (offset * 2000 - engine.playerX * 2000 + curveOffset) * engine.width) / 2;
  const y = engine.height * 0.6;
  return { x, y };
}

// poll the first connected gamepad into a fresh gamepad-input object.
// Keyboard inputs (in inputRef) are OR-merged with this at update time.
const DEADZONE = 0.14;
function readGamepad(): GameInput {
  const empty: GameInput = { left: false, right: false, accel: false, brake: false, nitro: false };
  const pads = typeof navigator !== "undefined" ? navigator.getGamepads?.() : null;
  if (!pads) return empty;
  const gp = pads[0];
  if (!gp) return empty;
  const lx = gp.axes[0] ?? 0;
  const rt = gp.buttons[7]?.value ?? 0; // right trigger = accelerate
  const lt = gp.buttons[6]?.value ?? 0; // left trigger = brake
  const aBtn = gp.buttons[0]?.pressed ?? false; // A = nitro
  // analog steering with a soft curve for finer control near center
  const steerRaw = Math.abs(lx) < DEADZONE ? 0 : lx - Math.sign(lx) * DEADZONE;
  const steerAnalog = steerRaw / (1 - DEADZONE); // remap to -1..1
  if (steerAnalog < 0) empty.left = true;
  else if (steerAnalog > 0) empty.right = true;
  if (rt > 0.05) { empty.accel = true; empty.accelAnalog = rt; }
  if (lt > 0.05) { empty.brake = true; empty.brakeAnalog = lt; }
  if (aBtn) empty.nitro = true;
  empty.steerAnalog = steerAnalog;
  return empty;
}

export default function RacingGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const rendererRef = useRef<Renderer | null>(null);
  const audioRef = useRef<AudioEngine | null>(null);
  const inputRef = useRef<GameInput>({
    left: false,
    right: false,
    accel: false,
    brake: false,
    nitro: false,
  });
  const rafRef = useRef<number>(0);
  const screenRef = useRef<Screen>("menu");
  const nitroWasDownRef = useRef(false);
  const ghostRecorderRef = useRef<GhostRecorder | null>(null);
  const ghostPlayerRef = useRef<GhostPlayer | null>(null);
  const lapStartTimeRef = useRef(0); // engine.currentTime at the start of the current lap

  const [screen, setScreen] = useState<Screen>("menu");
  const [view, setView] = useState<ViewMode>("chase");
  const [standings, setStandings] = useState<StandingRow[]>([]);
  const [results, setResults] = useState<Results>({
    finished: false,
    pos: 1,
    time: 0,
    best: 0,
    score: 0,
    splits: [],
    bestLap: 0,
  });
  const [soundOn, setSoundOn] = useState(true);
  const [difficulty, setDifficulty] = useState<Difficulty>("normal");
  const [trackId, setTrackId] = useState<1 | 2 | 3 | 4 | 5 | 6>(1);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [mirror, setMirror] = useState(false);
  const [lbVersion, setLbVersion] = useState(0); // bump to force leaderboard re-read after a finish
  const [showLeaderboard, setShowLeaderboard] = useState(false); // full leaderboard panel modal
  const [ghostBeatFlash, setGhostBeatFlash] = useState<{ delta: number } | null>(null);
  const [initials, setInitials] = useState<string>(""); // 3-letter initials for new records
  const [newRecords, setNewRecords] = useState<{ lap: boolean; score: boolean; total: boolean }>({
    lap: false,
    score: false,
    total: false,
  });
  const finishedNotifiedRef = useRef(false);

  // derived: best records for current track + difficulty (client-only localStorage read)
  // lbVersion forces re-read after a race finishes; typeof window guard handles SSR
  const lbEntry: LeaderboardEntry | null =
    typeof window !== "undefined" ? getCachedEntry(trackId, difficulty, lbVersion) : null;

  // ghost badge ref — toggled via direct DOM in useEffect (avoids hydration mismatch)
  const ghostBadgeRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const badge = ghostBadgeRef.current;
    if (!badge) return;
    const exists = loadGhost(trackId) !== null;
    badge.style.opacity = exists ? "1" : "0";
    badge.style.pointerEvents = exists ? "auto" : "none";
  }, [trackId, lbVersion]);

  // HUD refs (updated directly each frame to avoid re-renders)
  const speedRef = useRef<HTMLSpanElement>(null);
  const lapRef = useRef<HTMLSpanElement>(null);
  const timeRef = useRef<HTMLSpanElement>(null);
  const posRef = useRef<HTMLSpanElement>(null);
  const nitroRef = useRef<HTMLDivElement>(null);
  const countdownRef = useRef<HTMLDivElement>(null);
  const minimapRef = useRef<HTMLCanvasElement>(null);
  const comboRef = useRef<HTMLDivElement>(null);
  const comboLabelRef = useRef<HTMLSpanElement>(null);
  const comboBarRef = useRef<HTMLDivElement>(null);
  const scoreRef = useRef<HTMLSpanElement>(null);
  const splitRef = useRef<HTMLSpanElement>(null);
  const driftRef = useRef<HTMLDivElement>(null);
  const driftValRef = useRef<HTMLSpanElement>(null);
  const ghostDeltaRef = useRef<HTMLDivElement>(null);

  const setScreenBoth = useCallback((s: Screen) => {
    screenRef.current = s;
    setScreen(s);
  }, []);

  // ---------- audio init (lazy, on first user gesture) ----------
  const ensureAudio = useCallback(() => {
    if (!audioRef.current) audioRef.current = new AudioEngine();
    audioRef.current.ensure();
    audioRef.current.setEnabled(soundOn);
  }, [soundOn]);

  const toggleSound = useCallback(() => {
    setSoundOn((prev) => {
      const next = !prev;
      if (audioRef.current) {
        audioRef.current.ensure();
        audioRef.current.setEnabled(next);
      }
      return next;
    });
  }, []);

  const applyConfig = useCallback(() => {
    const e = engineRef.current;
    if (!e) return;
    e.difficulty = difficulty;
    e.trackId = trackId;
    e.mirror = mirror;
  }, [difficulty, trackId, mirror]);

  // ---------- view switching (declared before effects that use them) ----------
  const changeView = useCallback((v: ViewMode) => {
    setView(v);
    if (engineRef.current) engineRef.current.view = v;
    audioRef.current?.ensure();
    audioRef.current?.play("click");
  }, []);

  const cycleView = useCallback(() => {
    const order: ViewMode[] = ["chase", "hood", "cockpit"];
    const i = order.indexOf(engineRef.current?.view ?? "chase");
    changeView(order[(i + 1) % order.length]);
  }, [changeView]);

  const setupGhost = useCallback(() => {
    const e = engineRef.current;
    if (!e) return;
    // load best-lap ghost for this track (if any)
    const data = loadGhost(trackId);
    if (data) {
      ghostPlayerRef.current = new GhostPlayer(data);
      e.ghostEnabled = true;
      e.ghostLapTime = data.lapTime;
    } else {
      ghostPlayerRef.current = null;
      e.ghostEnabled = false;
      e.ghostLapTime = 0;
    }
    // fresh recorder for this race
    ghostRecorderRef.current = new GhostRecorder(trackId);
    ghostRecorderRef.current.reset();
    lapStartTimeRef.current = 0;
    e.ghost = null;
  }, [trackId]);

  const restart = useCallback(() => {
    applyConfig();
    engineRef.current?.reset();
    rendererRef.current?.particles.clear();
    finishedNotifiedRef.current = false;
    setupGhost();
    setResults({ finished: false, pos: 1, time: 0, best: engineRef.current?.bestTime ?? 0, score: 0, splits: [], bestLap: 0 });
    audioRef.current?.ensure();
    audioRef.current?.play("start");
  }, [applyConfig, setupGhost]);

  const startRace = useCallback(() => {
    ensureAudio();
    applyConfig();
    engineRef.current?.reset();
    rendererRef.current?.particles.clear();
    finishedNotifiedRef.current = false;
    setupGhost();
    setResults({ finished: false, pos: 1, time: 0, best: engineRef.current?.bestTime ?? 0, score: 0, splits: [], bestLap: 0 });
    setScreenBoth("race");
    audioRef.current?.play("start");
  }, [applyConfig, ensureAudio, setScreenBoth, setupGhost]);

  const backToMenu = useCallback(() => {
    engineRef.current?.reset();
    rendererRef.current?.particles.clear();
    finishedNotifiedRef.current = false;
    setResults({ finished: false, pos: 1, time: 0, best: engineRef.current?.bestTime ?? 0, score: 0, splits: [], bestLap: 0 });
    audioRef.current?.silenceEngine();
    setScreenBoth("menu");
  }, [setScreenBoth]);

  // ---------- minimap drawing ----------
  const drawMinimap = useCallback(
    (engine: GameEngine, rs: ReturnType<GameEngine["getRenderState"]>) => {
      const mc = minimapRef.current;
      if (!mc) return;
      const mctx = mc.getContext("2d")!;
      const W = mc.width;
      const H = mc.height;
      const cx = W / 2;
      const cy = H / 2;
      const rx = W * 0.4;
      const ry = H * 0.34;
      mctx.clearRect(0, 0, W, H);
      mctx.strokeStyle = "rgba(0,240,255,0.35)";
      mctx.lineWidth = 6;
      mctx.beginPath();
      mctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
      mctx.stroke();
      mctx.strokeStyle = "rgba(255,45,149,0.5)";
      mctx.lineWidth = 1.5;
      mctx.beginPath();
      mctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
      mctx.stroke();

      const ang = (z: number) => (z / engine.trackLength) * Math.PI * 2 - Math.PI / 2;
      for (const car of engine.cars) {
        const a = ang(car.z);
        const px = cx + Math.cos(a) * rx * (0.7 + car.offset * 0.3);
        const py = cy + Math.sin(a) * ry * (0.7 + car.offset * 0.3);
        mctx.fillStyle = car.spin > 0 ? "#ffffff" : car.color;
        mctx.beginPath();
        mctx.arc(px, py, 2.4, 0, Math.PI * 2);
        mctx.fill();
      }
      const pa = ang((engine.position + 1200) % engine.trackLength);
      const ppx = cx + Math.cos(pa) * rx * (0.7 + engine.playerX * 0.3);
      const ppy = cy + Math.sin(pa) * ry * (0.7 + engine.playerX * 0.3);
      mctx.fillStyle = "#3b82f6";
      mctx.strokeStyle = "#fde047";
      mctx.lineWidth = 1.5;
      mctx.beginPath();
      mctx.arc(ppx, ppy, 3.4, 0, Math.PI * 2);
      mctx.fill();
      mctx.stroke();
      // suppress unused rs
      void rs;
    },
    []
  );

  // ---------- HUD update (direct DOM writes each frame) ----------
  const updateHUD = useCallback(
    (engine: GameEngine) => {
      const rs = engine.getRenderState();
      const kmh = Math.round(rs.speedPercent * 320);
      if (speedRef.current) speedRef.current.textContent = String(kmh);
      if (lapRef.current)
        lapRef.current.textContent = `${Math.min(engine.lap + 1, engine.totalLaps)}/${engine.totalLaps}`;
      if (timeRef.current) timeRef.current.textContent = formatTime(engine.currentTime);
      if (posRef.current) {
        const p = rs.position;
        posRef.current.textContent = `${ordinal(p)} / ${rs.rankedCars.length}`;
        posRef.current.style.color =
          p === 1 ? "#fde047" : p === 2 ? "#e5e7eb" : p === 3 ? "#fb923c" : "#a5f3fc";
      }
      if (nitroRef.current) {
        nitroRef.current.style.width = `${engine.nitro}%`;
        nitroRef.current.style.background =
          engine.nitro > 25
            ? "linear-gradient(90deg,#ff2d95,#fb923c,#fde047)"
            : "linear-gradient(90deg,#7f1d1d,#ff2d95)";
      }
      if (countdownRef.current) {
        if (engine.raceState === "countdown") {
          const n = Math.ceil(engine.countdown);
          countdownRef.current.textContent = n <= 0 ? "GO!" : String(n);
          countdownRef.current.style.opacity = "1";
        } else {
          countdownRef.current.style.opacity = "0";
        }
      }
      // combo + score
      if (comboRef.current) {
        if (engine.combo > 1) {
          comboRef.current.style.opacity = "1";
          if (comboLabelRef.current)
            comboLabelRef.current.textContent = `${engine.comboLabel} x${Math.min(8, engine.combo)}`;
          if (comboBarRef.current)
            comboBarRef.current.style.width = `${Math.max(0, engine.comboTimer / 3) * 100}%`;
        } else {
          comboRef.current.style.opacity = "0";
        }
      }
      if (scoreRef.current) scoreRef.current.textContent = engine.score.toLocaleString();
      // lap split (last completed lap time)
      if (splitRef.current) {
        if (engine.lapSplits.length > 0) {
          const last = engine.lapSplits[engine.lapSplits.length - 1];
          splitRef.current.textContent = formatTime(last);
          splitRef.current.style.color =
            engine.bestLapTime > 0 && Math.abs(last - engine.bestLapTime) < 0.01
              ? "#fde047"
              : "#a5f3fc";
        } else {
          splitRef.current.textContent = "--:--.--";
        }
      }
      // drift indicator (live drift score)
      if (driftRef.current) {
        if (engine.drifting) {
          driftRef.current.style.opacity = "1";
          if (driftValRef.current) driftValRef.current.textContent = `+${engine.driftScore}`;
        } else {
          driftRef.current.style.opacity = "0";
        }
      }
      // live ghost-delta indicator (ahead/behind vs ghost)
      if (ghostDeltaRef.current) {
        if (engine.ghostEnabled && engine.ghost && engine.raceState === "racing") {
          ghostDeltaRef.current.style.opacity = "1";
          // convert z-delta to a rough time delta using current speed
          const timeDelta = engine.speed > 100 ? engine.ghostDelta / engine.speed : 0;
          const sign = timeDelta >= 0 ? "+" : "−";
          const abs = Math.abs(timeDelta).toFixed(1);
          ghostDeltaRef.current.textContent = `${sign}${abs}s ${timeDelta >= 0 ? "AHEAD" : "BEHIND"}`;
          ghostDeltaRef.current.style.color = timeDelta >= 0 ? "#22c55e" : "#f87171";
        } else {
          ghostDeltaRef.current.style.opacity = "0";
        }
      }
      drawMinimap(engine, rs);
    },
    [drawMinimap]
  );

  // ---------- init engine + loop ----------
  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d", { alpha: false })!;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const w = Math.max(640, Math.floor(rect.width * dpr));
      const h = Math.max(360, Math.floor(rect.height * dpr));
      canvas.width = w;
      canvas.height = h;
      if (engineRef.current) engineRef.current.resize(w, h);
      else {
        engineRef.current = new GameEngine(w, h);
        rendererRef.current = new Renderer();
      }
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    let last = performance.now();
    let acc = 0;
    const STEP = 1 / 60;

    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const engine = engineRef.current!;
      const renderer = rendererRef.current!;
      const audio = audioRef.current;

      // ---- merged input: keyboard (persistent) OR gamepad (per-frame) ----
      const gp = readGamepad();
      const merged: GameInput = {
        left: inputRef.current.left || gp.left,
        right: inputRef.current.right || gp.right,
        accel: inputRef.current.accel || gp.accel,
        brake: inputRef.current.brake || gp.brake,
        nitro: inputRef.current.nitro || gp.nitro,
      };

      if (screenRef.current === "race") {
        acc += dt;
        let steps = 0;
        while (acc >= STEP && steps < 5) {
          engine.update(STEP, merged);
          // ---- ghost recording (sample player position during the lap) ----
          if (engine.raceState === "racing") {
            ghostRecorderRef.current?.record(
              STEP,
              engine.position % engine.trackLength,
              engine.playerX,
              engine.speed,
              engine.trackLength
            );
          }
          // ---- event-driven SFX + particles ----
          if (engine.justBumped) {
            audio?.play("bump");
            const bp = engine.bumpPoint;
            if (bp) {
              const sp = projectImpact(engine, bp.z, bp.offset);
              if (sp) {
                renderer.particles.sparks(sp.x, sp.y, 18);
                // flying car debris at the impact
                renderer.particles.debris(sp.x, sp.y, "#ff2d95", 8);
              }
            }
          }
          if (engine.justTurbo) {
            audio?.play("nitro");
            // burst of flame when hitting a turbo pad
            renderer.particles.nitroTrail(engine.width / 2, engine.height * 0.96, engine.width * 0.12);
            renderer.particles.sparks(engine.width / 2, engine.height * 0.85, 10);
          }
          if (engine.justDrift) {
            audio?.play("lap"); // reuse the chime for a successful drift bank
            // celebratory sparks where the car is
            renderer.particles.sparks(engine.width / 2, engine.height * 0.9, 12);
          }
          if (engine.justLapped && engine.raceState !== "finished") {
            audio?.play("lap");
            // bank the ghost recording on each lap completion (best one wins)
            const rec = ghostRecorderRef.current?.finish();
            if (rec) saveGhostIfFaster(rec);
            // restart recorder for the next lap
            ghostRecorderRef.current?.reset();
          }
          // ghost-beaten flash + bonus
          if (engine.justBeatGhost) {
            audio?.play("finish");
            setGhostBeatFlash({ delta: engine.ghostBeatenDelta });
            // big celebratory spark burst
            renderer.particles.sparks(engine.width / 2, engine.height * 0.5, 30);
            renderer.particles.nitroTrail(engine.width / 2, engine.height * 0.9, engine.width * 0.2);
          }
          acc -= STEP;
          steps++;
        }

        // ---- update ghost car position from the player (best-lap replay) ----
        const gp2 = ghostPlayerRef.current;
        if (gp2 && engine.raceState === "racing") {
          const lapElapsed = engine.currentTime - lapStartTimeRef.current;
          const g = gp2.sample(lapElapsed, engine.trackLength);
          engine.ghost = g;
          // when the ghost finishes its lap, loop it
          if (lapElapsed >= gp2.lapTime) {
            lapStartTimeRef.current = engine.currentTime;
          }
        } else {
          engine.ghost = null;
        }

        // ---- continuous audio + particle updates ----
        const rs = engine.getRenderState();
        const offRoad = Math.abs(engine.playerX) > 1;
        const hardTurn = Math.abs(engine.steering) > 0.6 && rs.speedPercent > 0.4;
        audio?.updateEngine(rs.speedPercent, merged.nitro || engine.onPad, STEP);
        audio?.setScreech(
          (offRoad ? 1 : 0) * Math.min(1, rs.speedPercent * 1.5) +
            (hardTurn ? 0.9 : 0) +
            (engine.drifting ? 1 : 0)
        );
        // track-specific audio: tunnel reverb + rain ambience
        audio?.setReverb(engine.trackId === 4);
        audio?.setRain(engine.trackId === 5 ? 1 : 0);

        // drift smoke trail (both rear wheels)
        if (engine.drifting && engine.view === "chase") {
          const baseX = engine.width / 2;
          const baseY = engine.height * 0.95;
          const driftOffset = engine.steering * engine.width * 0.05;
          renderer.particles.smoke(baseX - engine.width * 0.05 + driftOffset, baseY, 2);
          renderer.particles.smoke(baseX + engine.width * 0.05 + driftOffset, baseY, 2);
        }

        // nitro flame trail (also on turbo pads)
        if ((merged.nitro && engine.nitro > 0 && engine.speed > 100) || engine.onPad) {
          if (engine.view === "chase") {
            renderer.particles.nitroTrail(engine.width / 2, engine.height * 0.96, engine.width * 0.08);
          }
        }
        // off-road tire smoke
        if (offRoad && engine.speed > 2000) {
          const sx = engine.width / 2 + engine.playerX * engine.width * 0.12;
          renderer.particles.smoke(sx, engine.height * 0.95, 3);
        }

        // nitro whoosh on press edge
        if (merged.nitro && !nitroWasDownRef.current && engine.nitro > 0) {
          audio?.play("nitro");
        }
        nitroWasDownRef.current = merged.nitro;

        renderer.particles.update(dt);
      } else {
        // gentle idle drift on the menu so the scene feels alive
        engine.position += 30 * dt;
        audio?.setScreech(0);
        audio?.updateEngine(0.06, false, STEP);
        audio?.setReverb(false);
        audio?.setRain(0);
      }

      renderer.render(ctx, engine);
      updateHUD(engine);

      if (
        screenRef.current === "race" &&
        engine.raceState === "finished" &&
        !finishedNotifiedRef.current
      ) {
        finishedNotifiedRef.current = true;
        audio?.play("finish");
        audio?.silenceEngine();
        const frs = engine.getRenderState();
        // bank the final-lap ghost recording (best lap wins)
        const ghostRec = ghostRecorderRef.current?.finish();
        if (ghostRec) saveGhostIfFaster(ghostRec);
        // record to localStorage leaderboard
        const rec = recordResult(engine.trackId, engine.difficulty, {
          bestLap: engine.bestLapTime,
          score: engine.score,
          bestTotal: engine.currentTime,
        });
        setLbVersion((v) => v + 1);
        setNewRecords({ lap: rec.newLap, score: rec.newScore, total: rec.newTotal });
        setResults({
          finished: true,
          pos: frs.position,
          time: engine.currentTime,
          best: engine.bestTime,
          score: engine.score,
          splits: [...engine.lapSplits],
          bestLap: engine.bestLapTime,
        });
      }

      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(rafRef.current);
      ro.disconnect();
    };
  }, [updateHUD]);

  // ---------- keyboard ----------
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      // init audio on any key (autoplay policy)
      if (!audioRef.current) audioRef.current = new AudioEngine();
      audioRef.current.ensure();
      const k = e.key.toLowerCase();
      if (k === "arrowleft" || k === "a") inputRef.current.left = true;
      if (k === "arrowright" || k === "d") inputRef.current.right = true;
      if (k === "arrowup" || k === "w") inputRef.current.accel = true;
      if (k === "arrowdown" || k === "s") inputRef.current.brake = true;
      if (k === " " || k === "shift") {
        inputRef.current.nitro = true;
        e.preventDefault();
      }
      if (k === "v") cycleView();
      if (k === "r" && screenRef.current === "race") restart();
      if (k === "m") toggleSound();
    };
    const up = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === "arrowleft" || k === "a") inputRef.current.left = false;
      if (k === "arrowright" || k === "d") inputRef.current.right = false;
      if (k === "arrowup" || k === "w") inputRef.current.accel = false;
      if (k === "arrowdown" || k === "s") inputRef.current.brake = false;
      if (k === " " || k === "shift") inputRef.current.nitro = false;
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, [cycleView, restart, toggleSound]);

  // ---------- standings poller (reads engine in effect, not render) ----------
  useEffect(() => {
    const id = setInterval(() => {
      const e = engineRef.current;
      if (!e) return;
      const rs = e.getRenderState();
      setStandings(
        rs.rankedCars.map((r) => ({
          name: r.car.name,
          color: r.car.color,
          isPlayer: r.isPlayer,
          spin: r.car.spin,
          laps: r.car.laps,
        }))
      );
    }, 350);
    return () => clearInterval(id);
  }, []);

  // ---------- pass reduced-motion to renderer ----------
  useEffect(() => {
    if (rendererRef.current) rendererRef.current.reducedMotion = reducedMotion;
  }, [reducedMotion]);

  // ---------- auto-clear ghost-beaten flash after 3s ----------
  useEffect(() => {
    if (!ghostBeatFlash) return;
    const id = setTimeout(() => setGhostBeatFlash(null), 3000);
    return () => clearTimeout(id);
  }, [ghostBeatFlash]);

  // ---------- touch helpers ----------
  const press =
    (key: keyof GameInput, val: boolean) =>
    (e: React.PointerEvent) => {
      inputRef.current[key] = val;
      e.preventDefault();
    };

  return (
    <div className="min-h-screen flex flex-col bg-[#05050d] text-slate-100 selection:bg-pink-500/40">
      {/* Header */}
      <header className="flex flex-wrap items-center justify-between gap-3 px-4 sm:px-6 py-3 border-b border-white/10 bg-black/40 backdrop-blur z-20">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-pink-500 to-cyan-400 grid place-items-center font-black text-black shadow-[0_0_18px_rgba(255,45,149,0.6)]">
            N
          </div>
          <div>
            <h1 className="text-lg sm:text-xl font-black tracking-tight leading-none">
              NEON <span className="text-pink-400">RACER</span>
            </h1>
            <p className="text-[10px] sm:text-xs text-cyan-300/70 tracking-widest">
              10 CARS · 3 VIEWS · BUMP TO WIN
            </p>
          </div>
        </div>

        {/* View selector + sound */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 rounded-full bg-white/5 p-1 border border-white/10">
            {VIEWS.map((v) => (
              <button
                key={v.id}
                onClick={() => changeView(v.id)}
                title={v.hint}
                className={`px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-semibold rounded-full transition-all ${
                  view === v.id
                    ? "bg-gradient-to-r from-pink-500 to-cyan-400 text-black shadow-[0_0_14px_rgba(0,240,255,0.5)]"
                    : "text-slate-300 hover:text-white hover:bg-white/10"
                }`}
              >
                {v.label}
              </button>
            ))}
          </div>
          <button
            onClick={toggleSound}
            title="Toggle sound (M)"
            aria-label="Toggle sound"
            className="h-9 w-9 grid place-items-center rounded-full border border-white/10 bg-white/5 text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
          >
            {soundOn ? "🔊" : "🔇"}
          </button>
          <button
            onClick={() => setReducedMotion((r) => !r)}
            title="Reduced motion (disables shake + scanlines)"
            aria-label="Toggle reduced motion"
            aria-pressed={reducedMotion}
            className={`h-9 px-2.5 grid place-items-center rounded-full border text-xs font-bold transition-colors ${
              reducedMotion
                ? "border-cyan-400/60 bg-cyan-400/15 text-cyan-300"
                : "border-white/10 bg-white/5 text-slate-300 hover:text-white hover:bg-white/10"
            }`}
          >
            RM
          </button>
        </div>
      </header>

      {/* Main game */}
      <main className="flex-1 flex flex-col lg:flex-row gap-3 p-3 sm:p-4">
        {/* Game viewport */}
        <section className="relative flex-1 min-h-[58vh] lg:min-h-0 rounded-2xl overflow-hidden border border-white/10 bg-black shadow-[0_0_40px_rgba(0,240,255,0.08)_inset]">
          <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full block touch-none"
          />

          {/* Top HUD */}
          <div className="pointer-events-none absolute top-0 inset-x-0 flex flex-wrap justify-center gap-2 p-2 sm:p-3 z-10">
            <HudChip label="SPEED" value={<span ref={speedRef}>0</span>} unit="km/h" color="cyan" />
            <HudChip label="LAP" value={<span ref={lapRef}>1/3</span>} color="pink" />
            <HudChip label="TIME" value={<span ref={timeRef}>0:00.00</span>} color="cyan" />
            <HudChip label="LAST" value={<span ref={splitRef}>--:--.--</span>} color="cyan" />
            <HudChip label="POS" value={<span ref={posRef}>1 / 10</span>} color="yellow" />
            <HudChip label="SCORE" value={<span ref={scoreRef}>0</span>} color="pink" />
          </div>

          {/* Combo meter (center-right, fades in when combo>1) */}
          <div
            ref={comboRef}
            className="pointer-events-none absolute right-3 top-20 sm:top-24 z-10 w-36 sm:w-44 transition-opacity duration-200"
            style={{ opacity: 0 }}
          >
            <div className="flex items-center justify-between mb-1">
              <span ref={comboLabelRef} className="text-xs font-black tracking-widest text-yellow-300 drop-shadow-[0_0_8px_rgba(253,224,71,0.6)]">
                COMBO x1
              </span>
            </div>
            <div className="h-1.5 rounded-full bg-black/60 border border-yellow-400/20 overflow-hidden">
              <div
                ref={comboBarRef}
                className="h-full rounded-full"
                style={{ width: "100%", background: "linear-gradient(90deg,#fde047,#fb923c,#ff2d95)" }}
              />
            </div>
          </div>

          {/* Drift indicator (left-center, fades in while drifting) */}
          <div
            ref={driftRef}
            className="pointer-events-none absolute left-3 top-20 sm:top-24 z-10 transition-opacity duration-100"
            style={{ opacity: 0 }}
          >
            <div className="px-3 py-2 rounded-xl bg-black/60 border border-cyan-400/40 backdrop-blur shadow-[0_0_16px_rgba(0,240,255,0.25)]">
              <div className="text-[10px] font-bold tracking-[0.2em] text-cyan-300 mb-0.5">DRIFT</div>
              <span ref={driftValRef} className="text-lg font-black font-mono text-white drop-shadow-[0_0_8px_rgba(0,240,255,0.7)]">
                +0
              </span>
            </div>
          </div>

          {/* Live ghost-delta indicator (top-center below HUD, fades in when ghost active) */}
          <div
            ref={ghostDeltaRef}
            className="pointer-events-none absolute left-1/2 -translate-x-1/2 top-16 sm:top-20 z-10 px-3 py-1.5 rounded-lg bg-black/60 border border-white/15 backdrop-blur text-sm font-black font-mono transition-opacity duration-200"
            style={{ opacity: 0, color: "#22c55e" }}
          >
            +0.0s AHEAD
          </div>

          {/* Nitro bar */}
          <div className="pointer-events-none absolute left-3 bottom-3 sm:bottom-4 z-10 w-40 sm:w-56">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-bold tracking-widest text-pink-300">NITRO</span>
              <span className="text-[10px] text-slate-400">SPACE</span>
            </div>
            <div className="h-2.5 rounded-full bg-black/60 border border-white/10 overflow-hidden">
              <div
                ref={nitroRef}
                className="h-full rounded-full transition-[width] duration-100"
                style={{ width: "100%", background: "linear-gradient(90deg,#ff2d95,#fb923c,#fde047)" }}
              />
            </div>
          </div>

          {/* Countdown */}
          <div
            ref={countdownRef}
            className="pointer-events-none absolute inset-0 z-20 grid place-items-center text-8xl sm:text-9xl font-black text-white drop-shadow-[0_0_30px_rgba(255,45,149,0.8)] transition-opacity"
            style={{ opacity: 0 }}
          >
            3
          </div>

          {/* Menu overlay */}
          {screen === "menu" && (
            <div className="absolute inset-0 z-30 grid place-items-center bg-gradient-to-b from-black/75 via-black/55 to-black/85 backdrop-blur-sm overflow-y-auto py-6">
              <div className="text-center px-6 max-w-xl w-full">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-500/15 border border-pink-400/40 text-pink-300 text-[11px] font-bold tracking-[0.2em] mb-4 animate-pulse">
                  <span className="h-1.5 w-1.5 rounded-full bg-pink-400" />
                  ARCADE RACING
                </div>
                <h2 className="text-5xl sm:text-7xl font-black leading-[0.9] mb-2 tracking-tight">
                  <span
                    className="bg-gradient-to-r from-pink-400 via-fuchsia-400 to-cyan-300 bg-clip-text text-transparent"
                    style={{ filter: "drop-shadow(0 0 18px rgba(255,45,149,0.45))" }}
                  >
                    NEON RACER
                  </span>
                </h2>
                <p className="text-slate-300/90 text-sm sm:text-base mb-5 max-w-md mx-auto">
                  Outrun 9 rivals on a neon night circuit. Bump them off the
                  track, slam the nitro, and switch between{" "}
                  <span className="text-cyan-300 font-semibold">3 camera views</span>.
                </p>

                {/* Track selector */}
                <div className="mb-4">
                  <div className="text-[10px] font-bold tracking-[0.2em] text-cyan-300/80 mb-2">SELECT TRACK</div>
                  <div className="grid grid-cols-2 gap-2">
                    {TRACKS.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => { setTrackId(t.id); setNewRecords({ lap: false, score: false, total: false }); audioRef.current?.ensure(); audioRef.current?.play("click"); }}
                        className={`rounded-xl border px-3 py-2.5 text-left transition-all ${
                          trackId === t.id
                            ? "border-cyan-300/60 bg-cyan-400/10 shadow-[0_0_16px_rgba(0,240,255,0.25)]"
                            : "border-white/10 bg-white/[0.03] hover:bg-white/[0.06]"
                        }`}
                      >
                        <div className="text-sm font-bold text-white">{t.name}</div>
                        <div className="text-[10px] text-slate-400">{t.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Difficulty selector */}
                <div className="mb-5">
                  <div className="text-[10px] font-bold tracking-[0.2em] text-pink-300/80 mb-2">DIFFICULTY</div>
                  <div className="grid grid-cols-3 gap-2">
                    {DIFFS.map((d) => (
                      <button
                        key={d.id}
                        onClick={() => { setDifficulty(d.id); setNewRecords({ lap: false, score: false, total: false }); audioRef.current?.ensure(); audioRef.current?.play("click"); }}
                        className={`rounded-xl border px-2 py-2 transition-all ${
                          difficulty === d.id
                            ? "border-pink-400/60 bg-pink-500/10 shadow-[0_0_16px_rgba(255,45,149,0.25)]"
                            : "border-white/10 bg-white/[0.03] hover:bg-white/[0.06]"
                        }`}
                      >
                        <div className="text-sm font-bold text-white">{d.label}</div>
                        <div className="text-[10px] text-slate-400">{d.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={startRace}
                  className="group relative px-10 py-4 rounded-xl font-black text-black text-lg bg-gradient-to-r from-pink-500 to-cyan-400 hover:scale-[1.04] active:scale-95 transition-transform shadow-[0_0_36px_rgba(0,240,255,0.5)]"
                >
                  START RACE
                  <span className="ml-2 inline-block group-hover:translate-x-1 transition-transform">▶</span>
                </button>

                <button
                  onClick={() => { audioRef.current?.ensure(); audioRef.current?.play("click"); setShowLeaderboard(true); }}
                  className="mt-3 px-4 py-2 rounded-lg text-xs font-bold text-cyan-300 border border-cyan-400/30 bg-cyan-400/5 hover:bg-cyan-400/10 transition-colors"
                >
                  🏆 FULL LEADERBOARD
                </button>

                <div className="mt-5 grid grid-cols-3 sm:grid-cols-6 gap-1.5 text-[11px] text-slate-400">
                  <KeyCap keys="◀ ▶ / A D" label="Steer" />
                  <KeyCap keys="▲ / W" label="Gas" />
                  <KeyCap keys="▼ / S" label="Brake" />
                  <KeyCap keys="SPACE" label="Nitro" />
                  <KeyCap keys="V" label="View" />
                  <KeyCap keys="M" label="Mute" />
                </div>

                {/* Best records for current track + difficulty */}
                {lbEntry && (lbEntry.bestLap > 0 || lbEntry.bestScore > 0) && (
                  <div className="mt-4 flex flex-wrap gap-2 justify-center text-[11px]">
                    {lbEntry.bestLap > 0 && (
                      <span className="px-2.5 py-1 rounded-md border border-yellow-400/40 bg-yellow-400/5 text-yellow-300 font-mono">
                        ★ Best Lap {formatTime(lbEntry.bestLap)}
                      </span>
                    )}
                    {lbEntry.bestScore > 0 && (
                      <span className="px-2.5 py-1 rounded-md border border-pink-400/40 bg-pink-500/5 text-pink-300 font-mono">
                        ★ Best Score {lbEntry.bestScore.toLocaleString()}
                      </span>
                    )}
                    {lbEntry.bestTotal > 0 && (
                      <span className="px-2.5 py-1 rounded-md border border-cyan-400/40 bg-cyan-400/5 text-cyan-300 font-mono">
                        ★ Best Total {formatTime(lbEntry.bestTotal)}
                      </span>
                    )}
                  </div>
                )}

                {/* Ghost-available indicator (always rendered, toggled via ref to avoid hydration mismatch) */}
                <div
                  ref={ghostBadgeRef}
                  className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-cyan-400/40 bg-cyan-400/10 text-cyan-300 text-[11px] font-bold transition-opacity"
                  style={{ opacity: 0, pointerEvents: "none" }}
                >
                  <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-pulse" />
                  GHOST READY — race your best lap
                </div>
              </div>
            </div>
          )}

          {/* Finish overlay */}
          {screen === "race" && results.finished && (
            <div className="absolute inset-0 z-30 grid place-items-center bg-black/75 backdrop-blur-sm">
              <div className="text-center px-6">
                <div className="text-7xl sm:text-8xl font-black mb-2 drop-shadow-[0_0_24px_rgba(253,224,71,0.6)]">
                  {results.pos === 1 ? "🏆" : results.pos <= 3 ? "🎉" : "🏁"}
                </div>
                <h2 className="text-3xl sm:text-5xl font-black mb-1">
                  {results.pos === 1 ? (
                    <span className="text-yellow-300">VICTORY!</span>
                  ) : (
                    <span className="text-cyan-300">FINISHED</span>
                  )}
                </h2>
                <p className="text-slate-300 mb-1">
                  Position{" "}
                  <span className="font-bold text-white">{ordinal(results.pos)}</span> of 10
                </p>
                <p className="text-slate-400 text-sm mb-3">
                  Total time{" "}
                  <span className="text-cyan-300 font-mono">
                    {formatTime(results.time)}
                  </span>
                  {results.best > 0 && (
                    <>
                      {" · Best "}
                      <span className="text-pink-300 font-mono">
                        {formatTime(results.best)}
                      </span>
                    </>
                  )}
                </p>
                {results.score > 0 && (
                  <p className="text-slate-300 text-sm mb-3">
                    Score{" "}
                    <span className="text-yellow-300 font-black font-mono">
                      {results.score.toLocaleString()}
                    </span>
                    {newRecords.score && (
                      <span className="ml-2 text-[10px] font-bold px-1.5 py-0.5 rounded bg-yellow-400/20 text-yellow-300 border border-yellow-400/40 align-middle">
                        NEW BEST!
                      </span>
                    )}
                  </p>
                )}
                {(newRecords.lap || newRecords.total) && (
                  <div className="mb-3 flex flex-wrap gap-2 justify-center">
                    {newRecords.lap && (
                      <span className="text-[11px] font-bold px-2 py-1 rounded bg-yellow-400/15 text-yellow-300 border border-yellow-400/40">
                        ★ NEW BEST LAP!
                      </span>
                    )}
                    {newRecords.total && (
                      <span className="text-[11px] font-bold px-2 py-1 rounded bg-cyan-400/15 text-cyan-300 border border-cyan-400/40">
                        ★ NEW BEST TOTAL!
                      </span>
                    )}
                  </div>
                )}
                {results.splits.length > 0 && (
                  <div className="mb-5 flex flex-wrap gap-2 justify-center max-w-sm mx-auto">
                    {results.splits.map((s, i) => (
                      <span
                        key={i}
                        className={`px-2 py-1 rounded-md text-[11px] font-mono border ${
                          results.bestLap > 0 && Math.abs(s - results.bestLap) < 0.01
                            ? "border-yellow-400/50 bg-yellow-400/10 text-yellow-300"
                            : "border-white/10 bg-white/[0.03] text-cyan-300"
                        }`}
                      >
                        L{i + 1} {formatTime(s)}
                        {results.bestLap > 0 && Math.abs(s - results.bestLap) < 0.01 && " ★"}
                      </span>
                    ))}
                  </div>
                )}
                <div className="flex gap-3 justify-center">
                  <button
                    onClick={restart}
                    className="px-6 py-3 rounded-xl font-bold text-black bg-gradient-to-r from-pink-500 to-cyan-400 hover:scale-105 active:scale-95 transition-transform"
                  >
                    RACE AGAIN
                  </button>
                  <button
                    onClick={backToMenu}
                    className="px-6 py-3 rounded-xl font-bold text-white bg-white/10 hover:bg-white/20 border border-white/15 transition-colors"
                  >
                    MENU
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Ghost-beaten flash overlay */}
          {screen === "race" && ghostBeatFlash && (
            <div className="pointer-events-none absolute inset-0 z-40 grid place-items-center">
              <div className="text-center animate-pulse">
                <div className="text-6xl sm:text-8xl font-black text-cyan-300 drop-shadow-[0_0_30px_rgba(0,240,255,0.9)]">
                  👻⚡
                </div>
                <div className="text-2xl sm:text-4xl font-black text-white mt-2 drop-shadow-[0_0_20px_rgba(0,240,255,0.7)]">
                  GHOST BEATEN!
                </div>
                <div className="text-sm text-cyan-200 font-mono mt-1">
                  −{ghostBeatFlash.delta.toFixed(2)}s · +500 BONUS
                </div>
              </div>
            </div>
          )}

          {/* Full leaderboard panel modal */}
          {showLeaderboard && (
            <LeaderboardPanel
              onClose={() => { setShowLeaderboard(false); audioRef.current?.play("click"); }}
              currentTrackId={trackId}
              currentDifficulty={difficulty}
              lbVersion={lbVersion}
            />
          )}
        </section>

        {/* Side panel: minimap + standings + controls */}
        <aside className="lg:w-72 flex flex-col gap-3">
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-3">
            <h3 className="text-xs font-bold tracking-widest text-cyan-300 mb-2">
              TRACK MAP
            </h3>
            <canvas
              ref={minimapRef}
              width={240}
              height={150}
              className="w-full rounded-lg bg-black/40"
            />
          </div>

          <Standings rows={standings} />

          {/* Mobile touch controls */}
          <div className="lg:hidden rounded-2xl border border-white/10 bg-white/[0.03] p-3">
            <h3 className="text-xs font-bold tracking-widest text-pink-300 mb-2">
              TOUCH CONTROLS
            </h3>
            <div className="grid grid-cols-3 gap-2">
              <TouchBtn label="◀" onDown={press("left", true)} onUp={press("left", false)} />
              <TouchBtn label="BRAKE" onDown={press("brake", true)} onUp={press("brake", false)} />
              <TouchBtn label="▶" onDown={press("right", true)} onUp={press("right", false)} />
              <TouchBtn label="GAS" onDown={press("accel", true)} onUp={press("accel", false)} wide />
              <TouchBtn label="NITRO" onDown={press("nitro", true)} onUp={press("nitro", false)} accent />
            </div>
          </div>
        </aside>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-white/10 bg-black/50 px-4 sm:px-6 py-2.5 text-[11px] sm:text-xs text-slate-400 flex flex-wrap items-center justify-between gap-2">
        <span>
          <span className="text-cyan-300 font-semibold">Tip:</span> Bump a rival
          from behind to spin them off and earn nitro. Stay on the asphalt —
          grass kills your speed.
        </span>
        <span className="font-mono text-slate-500">
          Arrow keys / WASD · SPACE nitro · V view · R restart
        </span>
      </footer>
    </div>
  );
}

// ---------- small presentational helpers ----------
function HudChip({
  label,
  value,
  unit,
  color,
}: {
  label: string;
  value: React.ReactNode;
  unit?: string;
  color: "cyan" | "pink" | "yellow";
}) {
  const c =
    color === "cyan"
      ? "text-cyan-300 border-cyan-400/30 shadow-[0_0_14px_rgba(0,240,255,0.15)]"
      : color === "pink"
      ? "text-pink-300 border-pink-400/30 shadow-[0_0_14px_rgba(255,45,149,0.15)]"
      : "text-yellow-300 border-yellow-400/30 shadow-[0_0_14px_rgba(253,224,71,0.15)]";
  return (
    <div className={`rounded-lg bg-black/55 backdrop-blur border ${c} px-2.5 sm:px-3 py-1 text-center min-w-[64px]`}>
      <div className="text-[9px] tracking-widest opacity-70 leading-none">{label}</div>
      <div className="font-mono font-bold text-sm sm:text-base leading-tight">
        {value}
        {unit && <span className="text-[9px] opacity-60 ml-0.5">{unit}</span>}
      </div>
    </div>
  );
}

function KeyCap({ keys, label }: { keys: string; label: string }) {
  return (
    <div className="rounded-lg bg-white/5 border border-white/10 px-2 py-1.5 text-center">
      <div className="font-mono text-cyan-300 text-[11px] font-bold">{keys}</div>
      <div className="text-[10px] text-slate-400">{label}</div>
    </div>
  );
}

function TouchBtn({
  label,
  onDown,
  onUp,
  wide,
  accent,
}: {
  label: string;
  onDown: (e: React.PointerEvent) => void;
  onUp: (e: React.PointerEvent) => void;
  wide?: boolean;
  accent?: boolean;
}) {
  return (
    <button
      onPointerDown={onDown}
      onPointerUp={onUp}
      onPointerLeave={onUp}
      onPointerCancel={onUp}
      className={`select-none rounded-xl py-3 font-bold text-sm active:scale-95 transition-transform border ${
        accent
          ? "bg-gradient-to-br from-pink-500 to-orange-400 text-black border-pink-300/50"
          : "bg-white/8 text-white border-white/15"
      } ${wide ? "col-span-2" : ""}`}
    >
      {label}
    </button>
  );
}

function Standings({ rows }: { rows: StandingRow[] }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-3 flex-1 min-h-0 flex flex-col">
      <h3 className="text-xs font-bold tracking-widest text-cyan-300 mb-2">
        STANDINGS
      </h3>
      <div className="max-h-64 lg:max-h-none overflow-y-auto custom-scroll flex-1 space-y-1">
        {rows.length === 0 && (
          <div className="text-xs text-slate-500 px-2 py-3">Loading grid…</div>
        )}
        {rows.map((r, i) => (
          <div
            key={r.name + i}
            className={`flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm ${
              r.isPlayer
                ? "bg-cyan-400/15 border border-cyan-300/40"
                : "bg-white/[0.02]"
            }`}
          >
            <span className="w-5 text-center font-mono font-bold text-slate-400">
              {i + 1}
            </span>
            <span
              className="h-3 w-3 rounded-full border border-white/30 shrink-0"
              style={{ background: r.color }}
            />
            <span className={`flex-1 truncate ${r.isPlayer ? "font-bold text-cyan-200" : "text-slate-300"}`}>
              {r.name}
            </span>
            {r.spin > 0 && <span className="text-[10px] text-pink-400">SPIN</span>}
            <span className="text-[10px] font-mono text-slate-500">
              L{r.laps + 1}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------- utils ----------
function formatTime(s: number) {
  if (s <= 0) return "0:00.00";
  const m = Math.floor(s / 60);
  const sec = (s % 60).toFixed(2).padStart(5, "0");
  return `${m}:${sec}`;
}
function ordinal(n: number) {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
}

// ---------- full leaderboard panel ----------
const TRACK_NAMES: Record<number, string> = {
  1: "Neon Circuit",
  2: "Twilight Spires",
  3: "Sunset Coast",
  4: "Neon Tunnel",
  5: "Neon Rain",
};

function LeaderboardPanel({
  onClose,
  currentTrackId,
  currentDifficulty,
  lbVersion,
}: {
  onClose: () => void;
  currentTrackId: number;
  currentDifficulty: string;
  lbVersion: number;
}) {
  // re-read when lbVersion changes (after a finish)
  void lbVersion;
  const entries =
    typeof window !== "undefined" ? getAllEntries() : [];

  return (
    <div
      className="absolute inset-0 z-50 grid place-items-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl rounded-2xl border border-cyan-400/30 bg-[#0a0a16] shadow-[0_0_40px_rgba(0,240,255,0.2)] max-h-[90vh] overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🏆</span>
            <h3 className="text-lg font-black tracking-tight">
              <span className="text-cyan-300">LEADERBOARD</span>
            </h3>
          </div>
          <button
            onClick={onClose}
            className="h-8 w-8 grid place-items-center rounded-full border border-white/10 bg-white/5 text-slate-300 hover:text-white hover:bg-white/10 transition-colors text-lg"
            aria-label="Close leaderboard"
          >
            ✕
          </button>
        </div>
        <div className="overflow-y-auto custom-scroll p-4 flex-1">
          {entries.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              <div className="text-4xl mb-3 opacity-40">🏁</div>
              <p className="text-sm">No records yet.</p>
              <p className="text-xs mt-1">Finish a race to set your first best time!</p>
            </div>
          ) : (
            <div className="space-y-2">
              {entries.map((e, i) => {
                const isCurrent =
                  e.trackId === currentTrackId && e.difficulty === currentDifficulty;
                return (
                  <div
                    key={`${e.trackId}-${e.difficulty}`}
                    className={`flex items-center gap-3 rounded-lg px-3 py-2.5 ${
                      isCurrent
                        ? "bg-cyan-400/10 border border-cyan-300/40"
                        : "bg-white/[0.02] border border-white/5"
                    }`}
                  >
                    <span className="w-6 text-center font-mono font-black text-slate-500 text-sm">
                      {i + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-bold text-white truncate">
                        {TRACK_NAMES[e.trackId] || `Track ${e.trackId}`}
                        <span className="ml-2 text-[10px] text-slate-400 uppercase tracking-wider">
                          {e.difficulty}
                        </span>
                      </div>
                      <div className="flex gap-3 text-[11px] text-slate-400 font-mono mt-0.5">
                        {e.entry.bestLap > 0 && (
                          <span className="text-yellow-300">★ {formatTime(e.entry.bestLap)}</span>
                        )}
                        {e.entry.bestTotal > 0 && (
                          <span className="text-cyan-300">⏱ {formatTime(e.entry.bestTotal)}</span>
                        )}
                        {e.entry.bestScore > 0 && (
                          <span className="text-pink-300">◈ {e.entry.bestScore.toLocaleString()}</span>
                        )}
                      </div>
                    </div>
                    {isCurrent && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-cyan-400/20 text-cyan-300 border border-cyan-400/40">
                        SELECTED
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
        <div className="px-5 py-3 border-t border-white/10 text-[10px] text-slate-500 text-center">
          Records persist in your browser · sorted by best lap time
        </div>
      </div>
    </div>
  );
}
