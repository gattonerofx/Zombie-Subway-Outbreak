import RacingGame from "@/components/racing/RacingGame";

export default function Home() {
  return <RacingGame />;
}
