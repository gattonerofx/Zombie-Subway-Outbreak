import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Neon Racer — Arcade Racing",
  description: "A neon arcade racer with 3 camera views, 10 cars, and bump-to-win gameplay. Chase cam, first-person hood view, and a full cockpit with a turning steering wheel.",
  keywords: ["racing game", "arcade racer", "neon racer", "OutRun", "pseudo-3D", "Next.js"],
  authors: [{ name: "Z.ai Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Neon Racer — Arcade Racing",
    description: "Neon arcade racer with 3 camera views and bump-to-win gameplay",
    url: "https://chat.z.ai",
    siteName: "Z.ai",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Neon Racer",
    description: "Neon arcade racer with 3 camera views and bump-to-win gameplay",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
